"""Read-only launch preflight. Pin an independently verified opening checkpoint on each network."""
import argparse
import json
import time
from dataclasses import replace
from pathlib import Path

from exchange.chain import Gateway, qty, tip
from exchange.config import ASSETS, Settings, require


def check(cfg, gateway):
    report={}
    for asset in ASSETS:
        net=cfg.networks[asset]
        require(net.witness_rpc, "Commissioning requires a second independently operated RPC for "+net.symbol)
        witness=replace(net,rpc=net.witness_rpc,witness_rpc="")
        for endpoint in (net,witness):gateway.identity(endpoint)
        target=min(tip(gateway,n,int(time.time())) for n in (net,witness))
        require(target>=net.anchor,"Requested opening height has not finalized")
        blocks=[gateway.block(n,net.anchor) for n in (net,witness)]
        require(all(b["hash"].lower()==net.anchor_hash and qty(b["number"])==net.anchor for b in blocks), "Opening hash differs from operator manifest")
        balances=[gateway.balance(n,net.anchor) for n in (net,witness)]
        require(balances[0]==balances[1] and all(gateway.code(n,net.vault,net.anchor)=="0x" for n in (net,witness)),
                "Nodes disagree on vault state or vault is a contract account")
        require(gateway.block(net,target)["hash"].lower()==gateway.block(witness,target)["hash"].lower(),
                "Nodes disagree on the settled tip")
        report[asset]={"symbol":net.symbol,"chain_id":net.chain_id,"genesis":net.genesis,
                       "vault":net.vault,"opening_height":net.anchor,"opening_hash":net.anchor_hash,
                       "opening_operator_capital_atoms":str(balances[0]),"corroborated_height":target}
    return report


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("config",type=Path)
    cfg=Settings.load(p.parse_args().config)
    print(json.dumps(check(cfg,Gateway()),indent=2))
