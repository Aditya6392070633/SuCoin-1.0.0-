"""Independent-SDK checks; run after installing network/requirements.txt."""
import copy
import unittest
from eth_account import Account
from eth_utils import keccak

from exchange.config import Fault
from .custody import plan_terms, validate_signed


class CustodySigning(unittest.TestCase):
    def setUp(self):
        self.signer=Account.create()
        self.plan={"withdrawal_id":51,"symbol":"BRK","genesis":"0x"+"12"*32,"gas_price_cap_wei":"2000000000",
                   "intent":{"from":self.signer.address.lower(),"to":Account.create().address.lower(),
                             "chainId":"0xbd1c9","nonce":"0x3","value":"0xde0b6b3a7640000","data":"0x","gas":"0x5208"}}
        terms=plan_terms(self.plan,1_000_000_000)
        self.raw=bytes(self.signer.sign_transaction(terms).raw_transaction)
        self.signed={"raw":"0x"+self.raw.hex()}

    def test_original_signature_recovers_expected_vault_and_hash(self):
        self.assertEqual(validate_signed(self.plan,self.signed),("0x"+keccak(self.raw).hex(),1_000_000_000))

    def test_changed_intent_fields_rejected(self):
        for field,value in [("chainId","0x1"),("nonce","0x4"),("to",Account.create().address),
                            ("value","0x1"),("data","0x01"),("gas","0x5209"),("from",Account.create().address)]:
            with self.subTest(field=field):
                p=copy.deepcopy(self.plan);p["intent"][field]=value
                with self.assertRaises(Fault):validate_signed(p,self.signed)

    def test_fee_above_cap_rejected(self):
        self.plan["gas_price_cap_wei"]="1"
        with self.assertRaisesRegex(Fault,"cap"):validate_signed(self.plan,self.signed)
