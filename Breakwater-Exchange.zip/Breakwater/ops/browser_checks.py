"""Exercise the real console and HTTP service using a funded disposable ledger."""
import os
import threading
import unittest
from wsgiref.simple_server import make_server

from playwright.sync_api import expect, sync_playwright

from exchange.config import UNIT
from exchange.http import application
from tests.fixtures import Case


class Console(Case):
    def test_order_and_cancellation_on_mobile_and_desktop(self):
        self.credit("alice", "base", 3 * UNIT)
        server = make_server("127.0.0.1", 0, application(self.engine))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        def close_server():
            server.shutdown()
            server.server_close()
            thread.join()
        self.addCleanup(close_server)
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path=os.environ.get("CHROMIUM_PATH"))
            try:
                page = browser.new_page(viewport={"width": 390, "height": 844})
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                page.goto(f"http://127.0.0.1:{server.server_port}")
                page.get_by_label("Access token").fill(self.tokens["alice"])
                page.get_by_role("button", name="Sign in").click()
                expect(page.locator("#pair")).to_have_text("BRK / TQ")
                expect(page.locator("#balances")).to_contain_text("3")
                expect(page.locator("#ops")).to_be_hidden()
                for width in (320, 390, 768, 1440):
                    with self.subTest(width=width):
                        page.set_viewport_size({"width": width, "height": 844})
                        self.assertTrue(page.evaluate(
                            "document.documentElement.scrollWidth <= window.innerWidth"),
                            f"Page overflows at {width}px")
                page.set_viewport_size({"width": 390, "height": 844})
                form = page.locator("#order-form")
                form.get_by_label("Side").select_option("sell")
                form.locator("input[name=quantity]").fill("1")
                form.locator("input[name=price]").fill("2")
                form.get_by_role("button", name="Review limit order").click()
                dialog = page.get_by_role("dialog")
                expect(dialog).to_contain_text("SELL 1 BRK at 2 TQ")
                dialog.get_by_role("button", name="Confirm").click()
                expect(page.locator("#orders")).to_contain_text("open")
                expect(page.locator("#balances")).to_contain_text("1 reserved")
                page.locator("#orders").get_by_role("button", name="Cancel").click()
                dialog.get_by_role("button", name="Confirm").click()
                expect(page.locator("#orders")).to_contain_text("cancel")
                self.assertEqual(self.balance("alice", "base"), 3 * UNIT)
                page.get_by_role("button", name="Sign out").click()
                expect(page.get_by_label("Access token")).to_be_visible()
                self.assertEqual(errors, [])
            finally:
                browser.close()


if __name__ == "__main__":
    unittest.main()
