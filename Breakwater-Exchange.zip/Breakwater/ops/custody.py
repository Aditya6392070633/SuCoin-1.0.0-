"""File handoff for external custodians. Only the offline sign subcommand reads a keystore."""
import argparse
import getpass
import json
import os
import sys
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

from exchange.chain import Gateway, NoRedirect, RpcError
from exchange.config import Settings, address, block_hash, exact, require


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, data):
    with Path(path).open("x", encoding="utf-8") as f:
        os.chmod(path, 0o600)
        json.dump(data, f, indent=2)


def plan_terms(plan, gas_price):
    exact(plan, ["withdrawal_id", "symbol", "genesis", "gas_price_cap_wei", "intent"])
    tx = plan["intent"]
    exact(tx, ["chainId","from","to","value","nonce","data","gas"])
    block_hash(plan["genesis"])
    source, dest = address(tx["from"]), address(tx["to"])
    require(source != dest and tx["data"] == "0x" and int(tx["gas"],16)==21000, "Unsupported custody intent")
    require(type(plan["withdrawal_id"]) is int and plan["withdrawal_id"] > 0, "Invalid request ID")
    require(0 < int(tx["value"],16) < 2**256 and int(tx["chainId"],16) > 0 and int(tx["nonce"],16)>=0, "Invalid signing terms")
    require(type(gas_price) is int and 0 < gas_price <= int(plan["gas_price_cap_wei"]), "Gas price exceeds the approved cap")
    return {"chainId":int(tx["chainId"],16),"nonce":int(tx["nonce"],16),"to":bytes.fromhex(dest[2:]),
            "value":int(tx["value"],16),"data":b"","gas":21000,"gasPrice":gas_price}


def review(plan, gas_price):
    tx=plan_terms(plan,gas_price)
    print(f"Request #{plan['withdrawal_id']} · chain {tx['chainId']} · {plan['symbol']}\n"
          f"Genesis: {plan['genesis']}\nVault: {plan['intent']['from']}\n"
          f"Recipient: {plan['intent']['to']}\nAmount (smallest units): {tx['value']}\n"
          f"Nonce: {tx['nonce']} · Maximum total fee of this transaction: {21000*gas_price} smallest units")


def offline_sign(plan, keystore, gas_price, output):
    from eth_account import Account
    terms=plan_terms(plan,gas_price)
    review(plan,gas_price)
    if input("Compare the independent approval record. Enter the withdrawal ID to sign: ").strip()!=str(plan["withdrawal_id"]):
        raise SystemExit("Cancelled")
    private=Account.decrypt(read(keystore),getpass.getpass("Keystore password: "))
    signer=Account.from_key(private)
    require(signer.address.lower()==plan["intent"]["from"].lower(), "Keystore does not control this vault")
    signed=signer.sign_transaction(terms)
    write_new(output, {"raw":"0x"+bytes(signed.raw_transaction).hex()})
    print("Saved the signed transaction for separate broadcast.")


def validate_signed(plan, signed):
    import rlp
    from eth_account import Account
    from eth_utils import keccak
    exact(signed,["raw"])
    raw=bytes.fromhex(signed["raw"].removeprefix("0x"))
    require(0<len(raw)<=2048 and raw[0]>=0xc0,"Expected a legacy EIP-155 signed transfer")
    fields=rlp.decode(raw, strict=True)
    require(isinstance(fields,list) and len(fields)==9 and all(isinstance(x,bytes) for x in fields),
            "Malformed signed transfer")
    nonce,price,gas,to,value,data,v,r,s=fields
    number=lambda b:int.from_bytes(b,"big")
    require(all(not x or x[0]!=0 for x in (nonce,price,gas,value,v,r,s)), "Non-canonical integer encoding")
    require(number(v)>=35 and number(r)>0 and number(s)>0,"Invalid signature fields")
    decoded={"chainId":(number(v)-35)//2,"nonce":number(nonce),"to":to,"value":number(value),
             "data":data,"gas":number(gas),"gasPrice":number(price)}
    require(decoded==plan_terms(plan,number(price)), "Signed transaction differs from the approved intent")
    require(Account.recover_transaction(raw).lower()==address(plan["intent"]["from"]), "Wrong custody signer")
    return "0x"+keccak(raw).hex(), number(price)


def exchange_post(url, token, ident):
    u=urlsplit(url)
    require(u.scheme=="https" or (u.scheme=="http" and u.hostname in ("127.0.0.1","localhost")), "Use HTTPS or local exchange")
    import secrets
    req=urllib.request.Request(url.rstrip("/")+"/api/commands/prepare",json.dumps({"id":ident}).encode(),
            {"Content-Type":"application/json","Authorization":"Bearer "+token,"Idempotency-Key":secrets.token_hex(20)})
    with urllib.request.build_opener(NoRedirect).open(req,timeout=25) as res:
        return json.load(res)


def broadcast(plan, signed, settings, exchange_url, token):
    h, price=validate_signed(plan,signed)
    matches=[n for n in settings.networks.values() if n.chain_id==int(plan["intent"]["chainId"],16)]
    require(len(matches)==1 and matches[0].vault==address(plan["intent"]["from"])
            and matches[0].genesis==plan["genesis"],"Plan does not match configured chain and vault")
    net=matches[0]; gateway=Gateway();gateway.identity(net)
    if gateway.rpc(net,"eth_getTransactionByHash",[h]):
        print("Transaction already known by node:",h);return h
    current=exchange_post(exchange_url,token,plan["withdrawal_id"])
    require(current==plan,"Current exchange approval differs from file")
    require(net.gas_price_cap >= price,"Current operator policy rejects this gas price")
    require(gateway.nonce(net,"latest")==int(plan["intent"]["nonce"],16),"Vault nonce changed. Reconcile before retrying")
    result=block_hash(gateway.rpc(net,"eth_sendRawTransaction",[signed["raw"]]))
    require(result==h, "Node returned an unexpected transaction hash")
    print("Submitted",h,"— the watcher confirms settlement.")
    return h


def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest="cmd",required=True)
    export=sub.add_parser("export");export.add_argument("id",type=int);export.add_argument("output")
    export.add_argument("--exchange",default="http://127.0.0.1:8080")
    sign=sub.add_parser("sign");sign.add_argument("plan");sign.add_argument("keystore");sign.add_argument("output")
    sign.add_argument("--gas-price-wei",type=int,required=True)
    check=sub.add_parser("verify");check.add_argument("plan");check.add_argument("signed")
    send=sub.add_parser("broadcast");send.add_argument("plan");send.add_argument("signed")
    send.add_argument("--config",default="runtime/exchange.json");send.add_argument("--exchange",default="http://127.0.0.1:8080")
    args=p.parse_args()
    if args.cmd=="export":
        write_new(args.output,exchange_post(args.exchange,getpass.getpass("Treasurer access token: "),args.id))
    elif args.cmd=="sign":
        offline_sign(read(args.plan),args.keystore,args.gas_price_wei,args.output)
    elif args.cmd=="verify":
        h, price=validate_signed(read(args.plan),read(args.signed));review(read(args.plan),price);print("Signed hash:",h)
    else:
        broadcast(read(args.plan),read(args.signed),Settings.load(args.config),args.exchange,getpass.getpass("Treasurer access token: "))


if __name__=="__main__":
    main()
