"""Deterministic RPC-node doubles for fault injection. They do not validate EVM signatures."""
import copy
import hashlib
import json
import os
import secrets
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace
import unittest

from exchange.chain import Gateway, RpcError, sync_one
from exchange.config import ASSETS, Network, Settings, UNIT
from exchange.market import allow_address
from exchange.service import Service, audit
from exchange.store import Store

def h(value):
    return "0x" + hashlib.sha256(str(value).encode()).hexdigest()

def addr(value):
    return "0x" + h(value)[-40:]


class Node:
    def __init__(self, name):
        self.name = name
        self.vault = addr(name+"vault")
        self.blocks = [{"hash":h(name+"genesis"),"parentHash":h("zero"),"number":"0x0",
                        "timestamp":hex(int(time.time())), "transactions":[]}]
        self.balances = [10*UNIT]
        self.receipts = {}
        self.vault_nonce = 0
        self.pending_nonce = None
        self.code_addresses = set()
        self.finalized = None

    def mine(self, transfers=(), drift=0):
        number = len(self.blocks)
        bh = h([self.name, number, self.blocks[-1]["hash"], transfers])
        block={"hash":bh,"number":hex(number),"parentHash":self.blocks[-1]["hash"],
               "timestamp":hex(int(time.time())),"transactions":[]}
        balance = self.balances[-1] + drift
        for i, row in enumerate(transfers):
            sender, dest, value, data = row["from"],row["to"],row["value"],row.get("data","0x")
            ok = row.get("ok",True)
            nonce = row.get("nonce",self.vault_nonce if sender==self.vault else 0)
            price = row.get("gas_price",1)
            tx_hash=h([bh, i])
            tx={"hash":tx_hash,"blockHash":bh,"blockNumber":hex(number),"transactionIndex":hex(i),
                "from":sender,"to":dest, "nonce":hex(nonce),"input":data,"value":hex(value),"gasPrice":hex(price)}
            self.receipts[tx_hash]={"transactionHash":tx_hash,"blockHash":bh,"blockNumber":hex(number),"transactionIndex":hex(i),
                                    "status":hex(int(ok)),"gasUsed":hex(21000),"effectiveGasPrice":hex(price)}
            if sender==self.vault:
                self.vault_nonce=max(nonce+1,self.vault_nonce)
                balance-=price*21000
                if ok: balance-=value
            if dest==self.vault and ok: balance+=value
            block["transactions"].append(tx)
        self.blocks.append(block); self.balances.append(balance)
        return block


class Nodes(Gateway):
    def __init__(self):
        self.nodes={a:Node(a) for a in ASSETS}
        self.unavailable = False
        self.calls=[]

    def rpc(self, net, method, params):
        self.calls.append(method)
        if self.unavailable: raise RpcError("test node unavailable")
        n=self.nodes[net.asset]
        def idx(tag):
            if tag in ("latest","pending"):return len(n.blocks)-1
            if tag=="finalized":return n.finalized if n.finalized is not None else max(0,len(n.blocks)-2)
            return int(tag,16)
        if method=="eth_chainId":return hex(7001 if net.asset=="base" else 7002)
        if method=="eth_syncing":return False
        if method=="eth_getBlockByNumber":
            i=idx(params[0]); return copy.deepcopy(n.blocks[i]) if i < len(n.blocks) else None
        if method=="eth_getBalance":return hex(n.balances[idx(params[1])])
        if method=="eth_getTransactionReceipt":return copy.deepcopy(n.receipts.get(params[0]))
        if method=="eth_getCode":return "0x6001" if params[0] in n.code_addresses else "0x"
        if method=="eth_gasPrice":return "0x1"
        if method=="eth_getTransactionCount":return hex(n.pending_nonce if params[1]=="pending" and n.pending_nonce is not None else n.vault_nonce)
        raise AssertionError(method)


class Case(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.nodes=Nodes()
        nets={}
        for i,(a,n) in enumerate(self.nodes.nodes.items()):
            net=Network(a,["BRK","TQ"][i],7001+i,n.blocks[0]["hash"],f"http://localhost:{18545+i}",
                        n.vault,0,n.blocks[0]["hash"],"qbft",1,1000*UNIT)
            nets[a]=net
            n.mine()
        database=str(Path(self.temp.name)/"ledger.sqlite")
        if os.environ.get("BREAKWATER_TEST_PG"):
            import psycopg
            from urllib.parse import urlencode
            base=os.environ["BREAKWATER_TEST_PG"]
            schema="bw_test_"+secrets.token_hex(8)
            with psycopg.connect(base,autocommit=True) as conn:
                conn.execute(f'CREATE SCHEMA "{schema}"')
            def clean():
                with psycopg.connect(base,autocommit=True) as conn:
                    conn.execute(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE')
            self.addCleanup(clean)
            self.pg_schema = schema
            database=base+("&" if "?" in base else "?")+urlencode({"options":"-csearch_path="+schema})
        self.cfg=Settings(nets,database,0,120)
        self.store=Store(self.cfg); self.store.init()
        self.engine=Service(self.store,self.nodes)
        self.tokens={n:self.store.enroll(n,r) for n,r in [("alice","customer"),("bob","customer"),("cara","customer"),
            ("reviewA","reviewer"),("reviewB","reviewer"),("signer","treasurer"),("auditUser","auditor")]}
        self.sync()
        self.count=0

    def sync(self):
        for n in self.cfg.networks.values():sync_one(self.store,n,self.nodes)

    def action(self, user, op, data, key=None):
        self.count+=1
        return self.engine.change(self.tokens[user],key or f"order-key-{self.count}",op,data)

    def credit(self, name, asset, value, **kwargs):
        tag=self.engine.read(self.tokens[name])["deposit_tag"]
        node=self.nodes.nodes[asset]
        block=node.mine([{"from":addr(name),"to":node.vault,"value":value,"data":tag,**kwargs}])
        node.mine(); self.sync(); return block["transactions"][0]["hash"]

    def balance(self,name,asset):
        with self.store.transaction(False) as db:return db.balance(asset,name+":available")

    def order(self,user,side,quantity,price):
        return self.action(user,"order",{"side":side,"quantity":quantity,"price":price})

    def request(self, name="alice", asset="base", value="2"):
        self.dest=addr("destination-"+name)
        with self.store.transaction() as db:allow_address(db,self.cfg,name,asset,self.dest)
        return self.action(name,"withdraw",{"address":self.dest,"asset":asset,"amount":value})["id"]

    def reserve_payout(self):
        self.credit("alice","base",6*UNIT)
        ident=self.request()
        for user in ("reviewA","reviewB"):self.action(user,"approve",{"id":ident})
        plan=self.action("signer","prepare",{"id":ident})
        return ident,plan["intent"]

    def confirm(self, intent, **overrides):
        node=self.nodes.nodes["base"]
        row={"from":intent["from"],"to":intent["to"],"value":int(intent["value"],16),
             "nonce":int(intent["nonce"],16),"data":intent["data"],**overrides}
        tx=node.mine([row])["transactions"][0];node.mine();self.sync();return tx

    def audit(self):
        with self.store.transaction(False) as db:return audit(db)
