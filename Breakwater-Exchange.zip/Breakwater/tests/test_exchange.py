import copy
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from io import BytesIO
from unittest import TestCase

from exchange.chain import Conflict, RpcError, sync_one
from exchange.config import CAPITAL_TAG, Fault, UNIT, amount, display
from exchange.http import application
from exchange.market import allow_address
from exchange.store import Store
from network.genesis import render, rlp
from .fixtures import Case, addr, h


class SettlementCases(Case):
    def test_unconfirmed_transfer_remains_uncredited(self):
        n=self.nodes.nodes["base"];tag=self.engine.read(self.tokens["alice"])["deposit_tag"]
        n.mine([{"from":addr("payer"),"to":n.vault,"value":3*UNIT,"data":tag}]);self.sync()
        self.assertEqual(self.balance("alice","base"),0)
        n.mine();self.sync()
        self.assertEqual(self.balance("alice","base"),3*UNIT)

    def test_restart_and_duplicate_scans_do_not_double_credit(self):
        tx=self.credit("alice","base",7*UNIT)
        store=Store(self.cfg);store.init()
        for _ in range(3):sync_one(store,self.cfg.networks["base"],self.nodes)
        self.assertEqual(self.balance("alice","base"),7*UNIT)
        with store.transaction(False) as db:
            self.assertEqual(len(db.rows("SELECT * FROM settlements WHERE hash=?",tx)),1)
        self.assertEqual(self.audit()["base"]["customer_liabilities"],"7")

    def test_failed_inbound_has_no_credit(self):
        self.credit("alice","base",2*UNIT,ok=False)
        self.assertEqual(self.balance("alice","base"),0)

    def test_two_transactions_in_same_block_route_to_separate_accounts(self):
        n=self.nodes.nodes["base"]
        n.mine([{"from":addr("payer"),"to":n.vault,"value":i*UNIT,"data":self.engine.read(self.tokens[name])["deposit_tag"]}
                for i,name in enumerate(("alice","bob"),1)]);n.mine();self.sync()
        self.assertEqual([self.balance(u,"base") for u in ("alice","bob")],[UNIT,2*UNIT])

    def test_untagged_and_capital_funding_segregated(self):
        self.credit("bob","base",2*UNIT,data="0x");self.credit("bob","base",3*UNIT,data=CAPITAL_TAG)
        self.assertEqual(self.audit()["base"],{"custody":"15","capital":"13","unassigned":"2","customer_liabilities":"0"})

    def test_receipt_for_another_block_halts_without_credit(self):
        n=self.nodes.nodes["base"];tag=self.engine.read(self.tokens["alice"])["deposit_tag"]
        tx=n.mine([{"from":addr("payer"),"to":n.vault,"value":UNIT,"data":tag}])["transactions"][0]
        n.receipts[tx["hash"]]["blockHash"]=h("other");n.mine()
        with self.assertRaises(Conflict):self.sync()
        self.assertEqual(self.balance("alice","base"),0)
        with self.assertRaisesRegex(Fault,"unavailable"):self.order("alice","sell","1","1")

    def test_missing_receipt_resumes_at_same_height(self):
        n=self.nodes.nodes["base"]
        tx=n.mine([{"from":addr("x"),"to":n.vault,"value":UNIT,"data":self.engine.read(self.tokens["alice"])["deposit_tag"]}])["transactions"][0]
        receipt=n.receipts.pop(tx["hash"]);n.mine()
        with self.assertRaises(RpcError):self.sync()
        self.assertEqual(self.balance("alice","base"),0)
        n.receipts[tx["hash"]]=receipt;self.sync()
        self.assertEqual(self.balance("alice","base"),UNIT)

    def test_pinned_genesis_and_chain_id_fail_closed(self):
        with self.assertRaises(Conflict):
            sync_one(self.store,replace(self.cfg.networks["base"],chain_id=1),self.nodes)
        with self.assertRaisesRegex(Fault,"halted"):self.sync()

    def test_finalized_history_conflict_freezes_both_markets(self):
        self.credit("alice","base",2*UNIT)
        self.nodes.nodes["base"].blocks[-2]["hash"]=h("changed")
        with self.assertRaises(Conflict):self.sync()
        with self.assertRaisesRegex(Fault,"unavailable"):self.order("alice","sell","1","1")

    def test_reserve_mismatch_persists_halt_after_restart(self):
        n=self.nodes.nodes["quote"];n.mine(drift=123);n.mine()
        with self.assertRaisesRegex(Fault,"Reserve mismatch"):self.sync()
        recovered=Store(self.cfg);recovered.init()
        with recovered.transaction(False) as db:
            self.assertIn("Reserve mismatch",db.one("SELECT halted FROM chains WHERE asset='quote'")["halted"])

    def test_sync_failure_invalidates_health_then_recovers(self):
        self.nodes.unavailable=True
        with self.assertRaises(RpcError):self.sync()
        with self.assertRaisesRegex(Fault,"unavailable"):self.order("alice","buy","1","1")
        self.nodes.unavailable=False;self.sync()
        self.assertTrue(self.engine.read(self.tokens["alice"])["networks"]["base"]["ready"])

    def test_old_head_prevents_spending(self):
        self.nodes.nodes["base"].blocks[-1]["timestamp"]="0x1"
        with self.assertRaisesRegex(RpcError,"stopped advancing"):self.sync()
        self.assertFalse(self.engine.read(self.tokens["alice"])["networks"]["base"]["ready"])

    def test_wrong_opening_identity_cannot_reuse_database(self):
        cfg=copy.deepcopy(self.cfg);cfg.networks["base"]=replace(cfg.networks["base"],vault=addr("another"))
        with self.assertRaisesRegex(Fault,"different networks"):Store(cfg).init()

    def test_ethereum_finalized_tag_stops_before_newer_transactions(self):
        n=self.nodes.nodes["base"]; n.finalized=0
        cfg=replace(self.cfg.networks["base"],finality="finalized")
        n.mine([{"from":addr("payer"),"to":n.vault,"value":UNIT,"data":self.engine.read(self.tokens["alice"])["deposit_tag"]}]);n.mine()
        sync_one(self.store,cfg,self.nodes);self.assertEqual(self.balance("alice","base"),0)
        n.finalized=2;sync_one(self.store,cfg,self.nodes);self.assertEqual(self.balance("alice","base"),UNIT)


class MarketCases(Case):
    def test_maker_price_partial_fill_release_and_cancel(self):
        self.credit("alice","base",10*UNIT);self.credit("bob","quote",20*UNIT)
        sell=self.order("alice","sell","5","2")
        self.order("bob","buy","2","3")
        self.assertEqual(self.balance("bob","quote"),16*UNIT)
        self.assertEqual(self.balance("alice","quote"),4*UNIT)
        self.assertEqual(self.balance("bob","base"),2*UNIT)
        self.action("alice","cancel-order",{"id":sell["id"]})
        self.assertEqual(self.balance("alice","base"),8*UNIT);self.audit()

    def test_buy_maker_gets_its_price_and_residual_can_cancel(self):
        self.credit("bob","quote",20*UNIT);self.credit("alice","base",5*UNIT)
        bid=self.order("bob","buy","4","3");self.order("alice","sell","1","2")
        self.assertEqual(self.balance("alice","quote"),3*UNIT)
        self.action("bob","cancel-order",{"id":bid["id"]})
        self.assertEqual(self.balance("bob","quote"),17*UNIT);self.audit()

    def test_best_price_then_arrival_time(self):
        for u in ("alice","cara"):self.credit(u,"base",3*UNIT)
        self.credit("bob","quote",10*UNIT)
        self.order("alice","sell","1","3");first=self.order("cara","sell","1","2");self.order("alice","sell","1","2")
        self.order("bob","buy","1","3")
        with self.store.transaction(False) as db:self.assertEqual(db.one("SELECT maker FROM trades")["maker"],first["id"])

    def test_crossing_own_order_after_one_fill_rolls_back_everything(self):
        self.credit("alice","quote",20*UNIT)
        for u in ("alice","bob"):self.credit(u,"base",2*UNIT)
        self.order("bob","sell","1","1");self.order("alice","sell","1","2")
        before=self.engine.read(self.tokens["alice"])
        with self.assertRaisesRegex(Fault,"own order"):self.order("alice","buy","2","3")
        after=self.engine.read(self.tokens["alice"]);self.assertEqual(before["balances"],after["balances"])
        self.assertEqual(after["trades"],[]);self.assertEqual(before["book"],after["book"]);self.audit()

    def test_minimum_tick_and_lot_settle_exactly(self):
        self.credit("alice","base",10**12);self.credit("bob","quote",10**6)
        self.order("alice","sell","0.000001","0.000001");self.order("bob","buy","0.000001","0.000001")
        self.assertEqual(self.balance("alice","quote"),10**6)
        self.assertEqual(self.balance("bob","base"),10**12);self.audit()

    def test_same_request_after_disconnect_returns_same_order(self):
        self.credit("alice","base",5*UNIT)
        payload={"side":"sell","quantity":"1","price":"2"}
        a=self.action("alice","order",payload,"retry-1234");b=self.action("alice","order",payload,"retry-1234")
        self.assertEqual(a,b);self.assertEqual(self.balance("alice","base"),4*UNIT)
        with self.assertRaisesRegex(Fault,"different input"):self.action("alice","order",{**payload,"price":"3"},"retry-1234")

    def test_two_concurrent_orders_cannot_spend_same_funds(self):
        self.credit("alice","base",5*UNIT)
        barrier=threading.Barrier(2)
        def take(i):
            barrier.wait()
            try:return self.action("alice","order",{"side":"sell","quantity":"4","price":"2"},"concurrent-"+str(i))["id"]
            except Fault:return None
        with ThreadPoolExecutor(2) as pool: results=list(pool.map(take,range(2)))
        self.assertEqual(sum(x is not None for x in results),1)
        self.assertEqual(self.balance("alice","base"),UNIT);self.audit()

    def test_users_cannot_cancel_others_orders_or_spend_past_balance(self):
        self.credit("alice","base",2*UNIT);o=self.order("alice","sell","2","2")
        with self.assertRaises(Fault):self.action("bob","cancel-order",{"id":o["id"]})
        with self.assertRaisesRegex(Fault,"Insufficient"):self.order("alice","sell","1","2")
        self.audit()


class PayoutCases(Case):
    def test_deposit_trade_approve_external_payout_and_reconcile(self):
        self.credit("alice","base",5*UNIT);self.credit("bob","quote",5*UNIT)
        self.order("alice","sell","2","2");self.order("bob","buy","2","2")
        ident=self.request("bob","base","1")
        for u in ("reviewA","reviewB"):self.action(u,"approve",{"id":ident})
        plan=self.action("signer","prepare",{"id":ident});tx=self.confirm(plan["intent"])
        self.assertEqual(self.balance("bob","base"),UNIT)
        row=self.engine.read(self.tokens["bob"])["withdrawals"][0]
        self.assertEqual((row["status"],row["tx_hash"]),("paid",tx["hash"]))
        self.assertEqual(self.audit()["base"]["customer_liabilities"],"4")
        self.assertLess(amount(self.audit()["base"]["capital"]),10*UNIT)

    def test_failed_canonical_payout_refunds_user_but_charges_fee_to_operator(self):
        ident,plan=self.reserve_payout();self.confirm(plan,ok=False)
        self.assertEqual(self.balance("alice","base"),6*UNIT)
        self.assertEqual(self.engine.read(self.tokens["alice"])["withdrawals"][0]["status"],"failed")
        self.assertEqual(self.audit()["base"]["capital"],display(10*UNIT-21000))

    def test_network_error_leaves_prepared_payout_reserved(self):
        ident,plan=self.reserve_payout()
        self.nodes.unavailable=True
        with self.assertRaises(RpcError):self.sync()
        self.assertEqual(self.balance("alice","base"),4*UNIT)
        with self.assertRaisesRegex(Fault,"prepared"):self.action("alice","cancel-withdrawal",{"id":ident})
        self.audit()

    def test_distinct_reviewers_and_separate_signer(self):
        self.credit("alice","base",4*UNIT);ident=self.request()
        with self.assertRaisesRegex(Fault,"Role"):self.action("alice","approve",{"id":ident})
        self.action("reviewA","approve",{"id":ident})
        with self.assertRaisesRegex(Fault,"different reviewer"):self.action("reviewA","approve",{"id":ident})
        with self.assertRaisesRegex(Fault,"Two distinct"):self.action("signer","prepare",{"id":ident})
        self.action("reviewB","approve",{"id":ident})
        with self.assertRaisesRegex(Fault,"Role"):self.action("reviewA","prepare",{"id":ident})

    def test_one_prepared_intent_per_network_and_repeatable_nonce(self):
        ident,plan=self.reserve_payout()
        self.assertEqual(plan,self.action("signer","prepare",{"id":ident})["intent"])
        second=self.request(value="1")
        for u in ("reviewA","reviewB"):self.action(u,"approve",{"id":second})
        with self.assertRaisesRegex(Fault,"previous signed intent"):self.action("signer","prepare",{"id":second})
        self.confirm(plan)
        self.assertEqual(self.action("signer","prepare",{"id":second})["intent"]["nonce"],"0x1")

    def test_modified_recipient_halts_without_marking_user_paid(self):
        ident,plan=self.reserve_payout()
        with self.assertRaisesRegex(Fault,"Unexpected outgoing"):self.confirm(plan,to=addr("different"))
        self.assertEqual(self.engine.read(self.tokens["alice"])["withdrawals"][0]["status"],"prepared")

    def test_unknown_destination_and_cooldown(self):
        self.credit("alice","base",3*UNIT)
        dest=addr("cold");data={"asset":"base","amount":"1","address":dest}
        with self.assertRaisesRegex(Fault,"cooling"):self.action("alice","withdraw",data)
        self.cfg.allowlist_delay=3600
        with self.store.transaction() as db:allow_address(db,self.cfg,"alice","base",dest)
        with self.assertRaisesRegex(Fault,"cooling"):self.action("alice","withdraw",data)

    def test_cancel_before_signing_releases_exact_hold(self):
        self.credit("alice","base",4*UNIT);ident=self.request()
        with self.assertRaises(Fault):self.action("bob","cancel-withdrawal",{"id":ident})
        self.action("alice","cancel-withdrawal",{"id":ident})
        self.assertEqual(self.balance("alice","base"),4*UNIT);self.audit()

    def test_pending_vault_nonce_and_contract_destination_fail_preparation(self):
        self.credit("alice","base",5*UNIT);ident=self.request()
        for u in ("reviewA","reviewB"):self.action(u,"approve",{"id":ident})
        n=self.nodes.nodes["base"];n.pending_nonce=1
        with self.assertRaisesRegex(Fault,"pending transaction"):self.action("signer","prepare",{"id":ident})
        n.pending_nonce=None;n.code_addresses.add(self.dest)
        with self.assertRaisesRegex(Fault,"ordinary accounts"):self.action("signer","prepare",{"id":ident})

    def test_per_request_limit_enforced(self):
        self.credit("alice","base",1001*UNIT)
        with self.assertRaisesRegex(Fault,"limit"):self.request(value="1001")
        self.assertEqual(self.balance("alice","base"),1001*UNIT)


class ControlCases(Case):
    def test_journal_is_append_only_and_replays_detect_corruption(self):
        self.credit("alice","base",UNIT)
        with self.assertRaises(Exception):
            with self.store.transaction() as db:db.sql("DELETE FROM moves")
        with self.store.transaction() as db:db.sql("UPDATE balances SET atoms='33' WHERE pocket='alice:available'")
        with self.assertRaisesRegex(Fault,"differs"):self.audit()

    def test_access_token_rotation_and_private_account_views(self):
        self.credit("alice","base",2*UNIT)
        self.assertEqual(self.engine.read(self.tokens["bob"])["deposits"],[])
        new=self.store.rotate("alice")
        with self.assertRaisesRegex(Fault,"revoked"):self.engine.read(self.tokens["alice"])
        self.assertEqual(self.engine.read(new)["balances"]["base"]["available"],"2")

    def test_http_routing_authentication_and_origin(self):
        app=application(self.engine)
        def fetch(path,method="GET",token="",payload=None,origin=None):
            raw=json.dumps(payload if payload is not None else {}).encode()
            env={"PATH_INFO":path,"REQUEST_METHOD":method,"HTTP_HOST":"localhost:8080","CONTENT_TYPE":"application/json",
                 "wsgi.input":BytesIO(raw),"CONTENT_LENGTH":str(len(raw)),"HTTP_AUTHORIZATION":"Bearer "+token,
                 "HTTP_IDEMPOTENCY_KEY":"http-request-1"}
            if origin:env["HTTP_ORIGIN"]=origin
            head=[];body=b"".join(app(env,lambda s,h:head.extend([s,dict(h)])))
            return head[0][:3],head[1],body
        self.assertEqual(fetch("/api/account")[0],"401")
        status,headers,body=fetch("/")
        self.assertEqual(status,"200");self.assertIn("frame-ancestors 'none'",headers["Content-Security-Policy"])
        self.assertIn(b"Breakwater",body)
        self.assertEqual(fetch("/api/commands/order","POST",self.tokens["alice"],{}, "https://another.invalid")[0],"403")
        self.assertEqual(fetch("/api/commands/approve","POST",self.tokens["alice"],{"id":1})[0],"403")
        self.assertEqual(fetch("/health/ready")[0],"200")


class InputCases(TestCase):
    def test_exact_amounts_and_rejected_notations(self):
        self.assertEqual(amount("123456789.000000000000000001"),123456789*UNIT+1)
        self.assertEqual(display(10**45),str(10**27))
        for bad in ["0","-1","1e3","0.0000000000000000001","0002","NaN",True,[],1.0]:
            with self.subTest(bad=bad),self.assertRaises(Fault):amount(bad)

    def test_qbft_genesis_quorum_and_public_only_input(self):
        manifest={"chain_id":774601,"timestamp":100,"block_period":2,"validators":[addr(i) for i in range(4)],
                  "allocation_wei":{addr(55):str(100*UNIT)}}
        result=render(manifest)
        self.assertTrue(result["extraData"].startswith("0xf87aa0"))
        self.assertTrue(result["extraData"].endswith("c080c0"))
        self.assertEqual(result["alloc"][addr(55)]["balance"],hex(100*UNIT))
        self.assertEqual(result,render({**manifest,"validators":manifest["validators"][::-1]}))
        with self.assertRaises(Fault):render({**manifest,"validators":[addr(1)]*4})
        with self.assertRaises(Fault):render({**manifest,"private_key":"unexpected"})
