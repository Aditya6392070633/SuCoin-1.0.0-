import json
import os
import sqlite3
import subprocess
import sys
import time
import unittest
import urllib.error
import urllib.request
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread

from exchange.chain import Conflict, Gateway, sync_one
from exchange.config import ASSETS, Fault, Settings, UNIT
from exchange.service import audit
from exchange.store import Store
from ops.commission import check
from ops.custody import plan_terms
from .fixtures import Case, addr


class OperatorCases(Case):
    def test_remote_networks_require_commissioned_witness_and_postgres(self):
        config = {"networks": {}}
        path = Path(self.temp.name) / "operator.json"
        for asset, net in self.cfg.networks.items():
            config["networks"][asset] = {"chain_id":net.chain_id,"symbol":net.symbol,
                "genesis":net.genesis,"rpc":f"https://primary-{asset}.example.invalid","vault":net.vault,
                "anchor_height":0,"anchor_hash":net.anchor_hash,"finality":"qbft","max_withdrawal":"1"}
        path.write_text(json.dumps(config))
        with self.assertRaisesRegex(Fault, "commissioned profile"):
            Settings.load(path)
        config["profile"] = "commissioned"
        path.write_text(json.dumps(config))
        with self.assertRaisesRegex(Fault, "second independently"):
            Settings.load(path)
        for asset, row in config["networks"].items():
            row["witness_rpc"] = f"https://secondary-{asset}.example.invalid"
        path.write_text(json.dumps(config))
        configured = Settings.load(path)
        with self.assertRaisesRegex(Fault, "PostgreSQL"):
            Store(replace(configured, database="unused.sqlite"))
        Store(replace(configured, database="postgresql://localhost/example"))

    def test_ethereum_l1_rejects_qbft_finality_policy(self):
        config = json.loads((Path(__file__).resolve().parents[1] / "ops" / "config.template.json").read_text())
        for asset, row in config["networks"].items():
            net = self.cfg.networks[asset]
            row.update({"chain_id":net.chain_id if asset == "base" else 1, "vault":net.vault,
                        "genesis":net.genesis,"anchor_hash":net.anchor_hash})
        config["networks"]["quote"]["finality"] = "qbft"
        path = Path(self.temp.name) / "wrong-finality.json"
        path.write_text(json.dumps(config))
        with self.assertRaisesRegex(Fault, "finalized"):
            Settings.load(path)

    def test_witness_disagreement_stops_credit(self):
        net = replace(self.cfg.networks["base"], witness_rpc="https://witness.invalid")
        node = self.nodes.nodes["base"]
        tag = self.engine.read(self.tokens["alice"])["deposit_tag"]
        node.mine([{"from":addr("p"), "to":node.vault, "value":5*UNIT, "data":tag}])
        node.mine()
        original = self.nodes.rpc
        def response(network, method, params):
            answer = original(network, method, params)
            if network.rpc == net.witness_rpc and method == "eth_getBlockByNumber" and params == ["0x2", True]:
                answer["transactions"][0]["input"] = "0x"
            return answer
        self.nodes.rpc = response
        with self.assertRaisesRegex(Conflict, "disagree"):
            sync_one(self.store, net, self.nodes)
        self.assertEqual(self.balance("alice","base"), 0)

    def test_preflight_compares_two_nodes_before_opening(self):
        with self.assertRaisesRegex(Fault, "second independently"):
            check(self.cfg, self.nodes)
        for a in ASSETS:
            self.cfg.networks[a] = replace(self.cfg.networks[a], witness_rpc="https://second.invalid")
        report = check(self.cfg, self.nodes)
        self.assertEqual(report["quote"]["opening_operator_capital_atoms"], str(10*UNIT))
        self.assertEqual(report["base"]["opening_height"],0)

    def test_payout_plan_pins_network_nonce_value_and_fee(self):
        ident, intent = self.reserve_payout()
        plan = self.action("signer","prepare",{"id":ident})
        terms = plan_terms(plan,1000)
        self.assertEqual(terms["chainId"],7001)
        self.assertEqual(terms["value"],2*UNIT)
        self.assertEqual(terms["nonce"],0)
        with self.assertRaisesRegex(Fault,"cap"):
            plan_terms(plan,int(plan["gas_price_cap_wei"])+1)

    def test_paid_payout_with_unapproved_fee_is_recorded_and_halted(self):
        ident, intent = self.reserve_payout()
        with self.assertRaisesRegex(Fault,"approved maximum fee"):
            self.confirm(intent,gas_price=self.cfg.networks["base"].gas_price_cap+1)
        self.assertEqual(self.engine.read(self.tokens["alice"])["withdrawals"][0]["status"],"paid")
        self.assertFalse(self.engine.read(self.tokens["alice"])["networks"]["base"]["ready"])
        self.audit()

    def test_onchain_reserve_shortfall_stops_new_orders_while_allowing_cancel(self):
        self.credit("alice","base",3*UNIT)
        ask = self.order("alice","sell","2","3")
        node = self.nodes.nodes["base"]
        node.mine(drift=-UNIT);node.mine()
        with self.assertRaises(Fault):self.sync()
        with self.assertRaisesRegex(Fault,"unavailable"):self.order("alice","sell","1","4")
        self.action("alice","cancel-order",{"id":ask["id"]})
        self.assertEqual(self.balance("alice","base"),3*UNIT)

    def restore_pg_fixture(self):
        import psycopg
        from psycopg import sql
        from psycopg.conninfo import conninfo_to_dict

        base = os.environ["BREAKWATER_TEST_PG"]
        # Only the disposable schema created in Case.setUp can ever be renamed.
        schema = self.pg_schema
        self.assertRegex(schema, r"^bw_test_[a-f0-9]{16}$")
        archive = schema + "_pre_restore"
        params = conninfo_to_dict(base)
        env = os.environ.copy()
        for key, value in params.items():
            env["PGDATABASE" if key == "dbname" else "PG" + key.upper()] = value
        backup = str(Path(self.temp.name) / "journal.dump")
        subprocess.run(["pg_dump", "--format=custom", "--no-owner", "--no-privileges",
                        "--schema", schema, "--file", backup], check=True, env=env)
        with psycopg.connect(base, autocommit=True) as con:
            con.execute(sql.SQL("ALTER SCHEMA {} RENAME TO {}").format(
                sql.Identifier(schema), sql.Identifier(archive)))
        def remove_archive():
            with psycopg.connect(base, autocommit=True) as con:
                con.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(archive)))
        self.addCleanup(remove_archive)
        subprocess.run(["pg_restore", "--single-transaction", "--no-owner", "--no-privileges",
                        "--dbname", params["dbname"], backup], check=True, env=env)
        return Store(self.cfg)

    def test_exact_report_after_database_backup_and_replay(self):
        self.credit("alice","base",8*UNIT);self.order("alice","sell","3","2")
        original = self.audit()
        if self.store.pg:
            restored = self.restore_pg_fixture()
        else:
            backup = str(Path(self.temp.name)/"restore.sqlite")
            source = sqlite3.connect(self.cfg.database); target = sqlite3.connect(backup)
            try:
                source.backup(target)
            finally:
                source.close();target.close()
            restored = Store(replace(self.cfg,database=backup))
        restored.init()
        for net in self.cfg.networks.values():
            sync_one(restored,net,self.nodes)
        with restored.transaction(False) as db:
            self.assertEqual(audit(db),original)
            self.assertEqual(db.balance("base","alice:available"),5*UNIT)

    def test_process_cli_observes_two_rpc_endpoints_and_http_api_persists_order(self):
        # Nodes are HTTP fixtures. The CLI, production HTTP client, database and WSGI process are real.
        nodes=self.nodes; urls={}
        listeners=[]
        for a in ASSETS:
            network=self.cfg.networks[a]
            def handler_for(net):
                class RpcHandler(BaseHTTPRequestHandler):
                    def do_POST(self):
                        msg=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                        result=nodes.rpc(net,msg["method"],msg["params"])
                        body=json.dumps({"jsonrpc":"2.0","id":msg["id"],"result":result}).encode()
                        self.send_response(200);self.send_header("Content-Type","application/json")
                        self.send_header("Content-Length",str(len(body)));self.end_headers();self.wfile.write(body)
                    def log_message(self,*args):
                        pass
                return RpcHandler
            server=ThreadingHTTPServer(("127.0.0.1",0),handler_for(network))
            thread=Thread(target=server.serve_forever,kwargs={"poll_interval":0.03},daemon=True);thread.start()
            listeners.append((server,thread));urls[a]="http://127.0.0.1:"+str(server.server_port)
        def close_servers():
            for server,thread in listeners:server.shutdown();server.server_close();thread.join()
        self.addCleanup(close_servers)
        config={"sqlite_file":"ledger.sqlite","allowlist_delay_seconds":0,"networks":{}}
        for a,n in self.cfg.networks.items():
            config["networks"][a]={"symbol":n.symbol,"rpc":urls[a],"chain_id":n.chain_id,"genesis":n.genesis,
                "anchor_height":0,"anchor_hash":n.anchor_hash,"vault":n.vault,"confirmations":1,
                "finality":"qbft","max_withdrawal":"1000"}
        path=Path(self.temp.name)/"service-config.json";path.write_text(json.dumps(config))
        env=os.environ.copy()
        for name in list(env):
            if name.startswith("BREAKWATER_"):del env[name]
        if self.store.pg:env["BREAKWATER_DATABASE_URL"]=self.cfg.database
        args=[sys.executable,"-m","exchange","--config",str(path)]
        def run(*cmd):
            return subprocess.run(args+list(cmd),capture_output=True,text=True,check=True,env=env,timeout=20).stdout
        self.assertIn("initialized",run("init"))
        n=nodes.nodes["base"]
        n.mine([{"from":addr("payer"),"to":n.vault,"value":4*UNIT,"data":self.engine.read(self.tokens["alice"])["deposit_tag"]}]);n.mine()
        run("sync")
        proc=subprocess.Popen(args+["serve","--port","0"],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        def stop():
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            proc.stdout.close();proc.stderr.close()
        self.addCleanup(stop)
        url=proc.stdout.readline().strip().split()[-1]
        headers={"Authorization":"Bearer "+self.tokens["alice"],"Content-Type":"application/json","Idempotency-Key":"rpc-http-order-1"}
        req=urllib.request.Request(url+"/api/commands/order",json.dumps({"side":"sell","quantity":"1.5","price":"2"}).encode(),headers)
        with urllib.request.urlopen(req,timeout=4) as r:
            self.assertEqual(json.load(r)["remaining"],"1.5")
        with urllib.request.urlopen(urllib.request.Request(url+"/api/account",headers=headers),timeout=4) as r:
            self.assertEqual(json.load(r)["balances"]["base"],{"available":"2.5","reserved":"1.5"})
        self.assertEqual(json.loads(run("audit"))["base"]["customer_liabilities"],"4")
