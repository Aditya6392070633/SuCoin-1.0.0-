# Breakwater exchange and independent blockchain

Breakwater is a separate source project for an operator who wants to run a native blockchain and a customer-deposit spot exchange. Its network uses Besu QBFT validators. Customers deposit native assets into an external custody wallet, trade balances at limit prices, and request on-chain withdrawals. Every customer credit must come from a confirmed deposit with a reconciled custody balance. There is no API to invent balances.

**Release status, 18 November 2026.** This is a commissioning candidate. The exchange accounting, custody controls and HTTP paths have been exercised locally. The included Besu and PostgreSQL acceptance paths still require a run in the target environment. The release has no independent audit, production custody integration certificate, regulatory registration or public deployment. See [the verification record](docs/VERIFICATION.md).

## Start on Windows

Extract the ZIP, open the inner **Breakwater** folder in File Explorer, type `powershell` in its address bar and press Enter. The folder contains `run.py`. These checks need Python 3.11 or newer and use only its standard library.

```powershell
py -3 --version
py -3 run.py test
```

For your first end-to-end rehearsal, start **Docker Desktop with its WSL 2 Linux engine**. The launcher runs eight Java validator containers. Allocate enough CPU and memory for them (8–12 GB of Docker memory is a starting estimate; measure on your machine). The first start needs internet access for the official Besu image and Python signing dependency. Then run:

```powershell
py -3 run.py start
```

The first start creates fresh validator and wallet keys, starts two four-validator chains, pins their genesis blocks, and runs the funded acceptance workflow. It signs deposits, matches a trade, cancels a remainder, obtains two approvals, signs a payout in a separate tool path and checks the recipient's balance. It prints three transaction hashes on success and starts the console at **http://127.0.0.1:8080**. The cash-like asset **TQ** in this preset is native to the second isolated chain. Its units have no redemption or external monetary value. No customer money is needed for the rehearsal.

The terminal prints the name of a local `runtime/lab/access-….json` file. Open it on your machine and enter the **seller** or **buyer** token at the console. Reviewer and treasurer tokens open their respective controls. The lab uses disposable principals for testing. Keep generated files private. Your personal wallet's seed phrase is never needed.

| Command in the project folder | Effect |
| --- | --- |
| `py -3 run.py test` | Runs local verification without Docker or third-party packages |
| `py -3 run.py start` | Starts or resumes the isolated nodes, watcher and customer/operator console |
| `py -3 run.py acceptance` | Executes a new funded rehearsal and exits, leaving the nodes up. Requires a clean order book |
| `py -3 run.py logs` | Shows validator logs |
| `py -3 run.py stop` | Stops the containers and retains balances, block history and volumes |

**Ctrl+C** in the console terminal stops the web server and watcher. Use the stop command to release the validator resources. On Linux substitute `python3` for `py -3`. Windows' Python installer includes the `py` launcher. If Docker reports a subnet conflict, choose two unused isolated subnets in the lab generator before creating a new rehearsal.

## Funds flow

1. **Deposit.** Each customer receives a unique 32-byte tag. Their wallet sends the native asset to the vault with that exact tag in the transaction data. A direct transfer with the wrong tag is recorded in the unassigned-funds account. The deposit form attaches the tag and verifies the selected chain ID and genesis hash.
2. **Confirm and reconcile.** The worker checks the correct chain, finalized checkpoint, transaction inclusion, receipt status and vault balance. It commits all effects and the cursor in one database transaction. The commissioned configuration checks a second independently operated RPC as well. A conflict suspends new orders, withdrawal approvals and signing plans.
3. **Trade.** Limit buys reserve quote currency. Limit sells reserve the base asset. The best opposing price fills first, then the earliest order at that price. Partial fills settle at the resting order's price. A buyer receives any price improvement. The remaining order can be cancelled. Trades settle in the exchange journal.
4. **Withdraw.** The customer selects an operator-verified destination and requests an amount. The journal reserves those funds. Two distinct reviewers approve and a separate treasurer exports an intent with the exact network, destination, amount, nonce and fee ceiling. A custody signer signs outside the exchange. The watcher marks payment complete once the transaction is confirmed. A confirmed failed payment releases the reservation and charges the actual network fee to the operator.
5. **Audit.** The journal can be replayed to verify every balance, every open-order reservation and every outstanding withdrawal. The watcher independently compares the custody account to on-chain funds at the same block.

## Commissioning for real assets

Start with [the commissioning guide](docs/COMMISSIONING.md). It covers creating your own genesis, distributing validators across independent operators, binding a real settlement network, configuring independently controlled custody wallets, provisioning customers, using PostgreSQL, signing and broadcasting, restoring state and resolving exceptions.

The supported market is a pair of **native 18-decimal EVM assets on two distinct networks**. One can be your independent QBFT coin and the other can be ETH on Ethereum L1. Deposits and payouts use ordinary externally owned custody accounts. An MPC provider can control such an account. ERC-20 tokens, fiat deposits, card/UPI rails and contract-wallet custody require additional adapters. The exchange price comes from orders backed by actual deposits. The operator supplies any initial market liquidity.

| Directory | Contents |
| --- | --- |
| `exchange/` | Ledger, order matching, watch-only chain ingestion, withdrawal workflow, WSGI API and operator CLI |
| `network/` | Public genesis generator, isolated Besu deployment and funded acceptance run |
| `web/` | Responsive customer, reviewer and treasurer consoles |
| `ops/` | External signing/broadcast utility, dual-node preflight, deployment templates and signer checks |
| `tests/` | Accounting, concurrency, custody, failure and recovery tests |
| `.github/workflows/` | Reproducible jobs for SQLite, PostgreSQL, custody signing and optional Besu acceptance |

The application requires no third-party Python modules for the SQLite exchange, web console, journal and RPC watcher. The release uses upstream Besu for blockchain consensus and `eth-account` for external key operations. No generated keys, live addresses, user secrets or funded wallets are included.
