"""One-workstation acceptance fleet. Generated test keys are isolated under runtime/lab."""
import argparse
import json
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from exchange.chain import Gateway
from exchange.config import Settings
from .genesis import render

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "runtime"
LAB = RUNTIME / "lab"
NAMES = ("base", "quote")
PORTS = {"base": 18545, "quote": 28545}
IDS = {"base": 774601, "quote": 774602}
IMAGE = "hyperledger/besu:26.10.2"


def save(path, payload, private=False):
    with path.open("x", encoding="utf-8") as f:
        if private:
            os.chmod(path, 0o600)
        json.dump(payload, f, indent=2)


def create():
    from eth_account import Account
    from eth_keys import keys
    RUNTIME.mkdir(exist_ok=True)
    if LAB.exists():
        raise SystemExit("Existing lab preserved. Use 'up' to restart its nodes.")
    temp = Path(tempfile.mkdtemp(prefix="building-", dir=RUNTIME))
    try:
        wallets = {}
        composition = {"name": "breakwater-acceptance", "services": {}, "volumes": {}, "networks": {}}
        for i, name in enumerate(NAMES):
            fleet = temp / name
            fleet.mkdir()
            keyring = {role: Account.create(secrets.token_bytes(32)) for role in ("funding", "vault", "recipient")}
            wallets[name] = {r: {"address": value.address, "key": "0x" + bytes(value.key).hex()} for r, value in keyring.items()}
            nodes = [Account.create(secrets.token_bytes(32)) for _ in range(4)]
            subnet = "172.29." + str(80 + i)
            composition["networks"][name] = {"internal": False, "ipam": {"config": [{"subnet": subnet+".0/24"}]}}
            peers = []
            for j, v in enumerate(nodes):
                pub = keys.PrivateKey(bytes(v.key)).public_key.to_bytes().hex()
                peers.append(f"enode://{pub}@{subnet}.{10+j}:30303")
            allocations = {keyring["funding"].address: str(10000*10**18), keyring["vault"].address: str(10**18)}
            manifest = {"chain_id": IDS[name], "validators": [n.address for n in nodes], "allocation_wei": allocations,
                        "timestamp": int(time.time())-5, "block_period": 3}
            save(fleet/"manifest.json", manifest)
            save(fleet/"genesis.json", render(manifest))
            for j, node in enumerate(nodes):
                folder = fleet / str(j)
                folder.mkdir()
                # Node key is for this isolated dev fleet only. Bind only this node's key.
                (folder/"key").write_text(bytes(node.key).hex(), encoding="ascii")
                os.chmod(folder/"key", 0o644)  # Parent lab directory is mode 0700.
                save(folder/"peers.json", [p for k,p in enumerate(peers) if k != j])
                ident = name+str(j)
                rel = "./"+name+"/"
                flags = ["--data-path=/data", "--genesis-file=/config/genesis.json", "--node-private-key-file=/keys/key",
                         "--static-nodes-file=/config/static-nodes.json", "--discovery-enabled=false",
                         "--p2p-host="+subnet+"."+str(10+j), "--sync-mode=FULL", "--min-gas-price=0",
                         "--host-allowlist=localhost,127.0.0.1", "--rpc-http-api=ETH,NET,WEB3"]
                item = {"image": IMAGE, "init": True, "environment": {"JAVA_OPTS":"-Xms128m -Xmx512m"},
                        "volumes": [ident+"-db:/data",rel+"genesis.json:/config/genesis.json:ro",
                                    rel+str(j)+"/key:/keys/key:ro",rel+str(j)+"/peers.json:/config/static-nodes.json:ro"],
                        "networks": {name: {"ipv4_address":subnet+"."+str(10+j)}}, "command": flags}
                # Private lab directory on the host; each node sees only its own read-only key mount.
                item["user"] = "0:0"
                item["cap_drop"] = ["ALL"]
                item["security_opt"] = ["no-new-privileges:true"]
                if j == 0:
                    flags.extend(["--data-storage-format=FOREST","--rpc-http-enabled",
                                  "--rpc-http-host=0.0.0.0","--rpc-http-port=8545"])
                    item["ports"] = [f"127.0.0.1:{PORTS[name]}:8545"]
                composition["services"][ident] = item
                composition["volumes"][ident+"-db"] = {}
        save(temp/"wallets.local.json", wallets, private=True)
        save(temp/"compose.json", composition)
        temp.rename(LAB)
    except BaseException:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    print(f"Generated eight validator keys and two isolated networks in {LAB}. Local test keys stay on this workstation.")


def compose(*args):
    subprocess.run(["docker","compose","-f",str(LAB/"compose.json"),*args],check=True)


def bind():
    # Only the locally generated rehearsal may pin from a single localhost endpoint.
    keyring = json.loads((LAB/"wallets.local.json").read_text())
    nets = {}
    for name in NAMES:
        url = f"http://127.0.0.1:{PORTS[name]}"
        from types import SimpleNamespace
        peer = SimpleNamespace(rpc=url)
        gateway = Gateway()
        for i in range(100):
            try:
                if int(gateway.rpc(peer,"eth_chainId",[]),16) != IDS[name]:
                    raise ValueError("Unexpected chain ID on the local lab port")
                genesis = gateway.block(peer,0)
                if int(gateway.block(peer,"latest")["number"],16) >= 3:
                    break
            except (OSError, RuntimeError) as err:
                if i == 99: raise
            except Exception as err:
                from exchange.chain import RpcError
                if not isinstance(err, RpcError): raise
            time.sleep(2)
        else:
            raise SystemExit(f"{name}: validators did not advance. Inspect docker compose logs in runtime/lab.")
        expected = json.loads((LAB/name/"genesis.json").read_text())
        if genesis["extraData"].lower() != expected["extraData"].lower():
            raise SystemExit(f"{name}: wrong genesis validators; check the node volumes")
        nets[name] = {"symbol": "BRK" if name=="base" else "TQ", "chain_id": IDS[name], "rpc":url,
                      "genesis":genesis["hash"], "anchor_height":0,"anchor_hash":genesis["hash"],
                      "vault":keyring[name]["vault"]["address"],"finality":"qbft","confirmations":2,"max_withdrawal":"100"}
    cfg = {"profile":"lab","networks":nets,"allowlist_delay_seconds":0,"sqlite_file":"exchange.sqlite","max_sync_age_seconds":90}
    path = RUNTIME/"exchange.json"
    if path.exists():
        if json.loads(path.read_text()) != cfg:
            raise SystemExit("Existing exchange configuration differs; no files overwritten")
    else:
        save(path,cfg)
    Settings.load(path)
    print("Local nodes are advancing. Exchange configuration pinned to their genesis blocks.")


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("command",choices=["create","up","bind","stop","logs"])
    action=p.parse_args().command
    if action=="create":
        create()
    elif action=="up":
        compose("up","-d"); bind()
    elif action=="stop":
        compose("stop")
    elif action=="logs":
        compose("logs","--tail","60")
    else:
        bind()
