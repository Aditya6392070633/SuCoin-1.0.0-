"""Exercise application code against the actual isolated Besu nodes; refuse any other network."""
import json
import os
import secrets
import time
from pathlib import Path
from wsgiref.simple_server import make_server
from threading import Thread
import urllib.request

from eth_account import Account
from eth_utils import keccak

from exchange.chain import Gateway, sync_one
from exchange.config import ASSETS, Settings, UNIT, require
from exchange.http import application
from exchange.market import allow_address
from exchange.service import Service, audit
from exchange.store import Store
from ops.custody import plan_terms, validate_signed, broadcast
from .lab import IDS, LAB, PORTS, RUNTIME


def confirm_until(store, gateway, passed, seconds=120):
    end=time.monotonic()+seconds
    while time.monotonic()<end:
        for n in store.cfg.networks.values():sync_one(store,n,gateway,batch=256)
        if passed():return
        time.sleep(1.0)
    raise RuntimeError("Timeout waiting for confirmed settlement; check node logs, readiness and journal.")


def main():
    if any(os.environ.get(k) for k in ("BREAKWATER_DATABASE_URL","BREAKWATER_BASE_RPC","BREAKWATER_QUOTE_RPC","BREAKWATER_BASE_WITNESS_RPC","BREAKWATER_QUOTE_WITNESS_RPC")):
        raise SystemExit("The funded rehearsal refuses external database and RPC overrides.")
    cfg=Settings.load(RUNTIME/"exchange.json");gateway=Gateway();wallets=json.loads((LAB/"wallets.local.json").read_text())
    for a,n in cfg.networks.items():
        require(n.chain_id==IDS[a] and n.rpc==f"http://127.0.0.1:{PORTS[a]}" and n.vault==wallets[a]["vault"]["address"].lower(),
                "The acceptance signer works only with this workspace's isolated network")
        gateway.identity(n)
        expected=json.loads((LAB/a/"genesis.json").read_text())
        require(gateway.block(n,0)["extraData"].lower()==expected["extraData"].lower(), "Local validator set differs")
    store=Store(cfg);store.init();service=Service(store,gateway)
    instance=secrets.token_hex(4)
    names={r:r+"-"+instance for r in ("seller","buyer","reviewA","reviewB","treasurer")}
    tokens={r:store.enroll(name,"customer" if r in ("seller","buyer") else "reviewer" if r.startswith("review") else "treasurer")
            for r,name in names.items()}
    credentials=LAB/("access-"+instance+".json")
    with credentials.open("x",encoding="utf-8") as f:
        os.chmod(credentials,0o600);json.dump({"principals":names,"tokens":tokens},f,indent=2)
    print("Isolated console access saved in",credentials,flush=True)
    print("Use the seller or buyer token to sign in to the browser.",flush=True)
    server=make_server("127.0.0.1",0,application(service))
    thread=Thread(target=server.serve_forever,daemon=True);thread.start()
    origin=f"http://127.0.0.1:{server.server_port}"
    def api(user,command=None,body=None):
        headers={"Authorization":"Bearer "+tokens[user]}
        url="/api/account"
        data=None
        if command:
            url="/api/commands/"+command;data=json.dumps(body).encode()
            headers.update({"Content-Type":"application/json","Idempotency-Key":secrets.token_hex(18)})
        with urllib.request.urlopen(urllib.request.Request(origin+url,data,headers),timeout=20) as res:
            return json.load(res)
    def snapshot(user):return api(user)["balances"]
    def funded(a,owner,atoms):
        net=cfg.networks[a]
        signer=Account.from_key(wallets[a]["funding"]["key"])
        nonce=int(gateway.rpc(net,"eth_getTransactionCount",[signer.address,"pending"]),16)
        terms={"chainId":net.chain_id,"nonce":nonce,"to":bytes.fromhex(net.vault[2:]),"value":atoms,"gas":60000,
               "gasPrice":max(2_000_000_000,gateway.gas_price(net)*2),"data":bytes.fromhex(api(owner)["deposit_tag"][2:])}
        signed=signer.sign_transaction(terms)
        raw=bytes(signed.raw_transaction)
        tx_hash=gateway.rpc(net,"eth_sendRawTransaction",["0x"+raw.hex()])
        require(tx_hash=="0x"+keccak(raw).hex(),"Deposit hash mismatch")
        return tx_hash
    try:
        confirm_until(store,gateway,lambda: all(n["ready"] for n in api("buyer")["networks"].values()))
        # Other users' orders would change prices; clean starting books are necessary for these exact assertions.
        require(all(not levels for levels in api("buyer")["book"].values()), "Run acceptance on a clean order book")
        base_tx=funded("base","seller",5*UNIT);quote_tx=funded("quote","buyer",10*UNIT)
        confirm_until(store,gateway,lambda:snapshot("seller")["base"]["available"]=="5" and snapshot("buyer")["quote"]["available"]=="10")
        sell=api("seller","order",{"side":"sell","quantity":"4","price":"2"})
        api("buyer","order",{"side":"buy","quantity":"2","price":"3"})
        require(snapshot("buyer")["quote"]["available"]=="6" and snapshot("seller")["base"]["reserved"]=="2", "Partial fill incorrect")
        api("seller","cancel-order",{"id":sell["id"]})
        dest=wallets["base"]["recipient"]["address"]
        with store.transaction() as db:allow_address(db,cfg,names["buyer"],"base",dest)
        request=api("buyer","withdraw",{"asset":"base","amount":"1","address":dest})
        for role in ("reviewA","reviewB"):api(role,"approve",{"id":request["id"]})
        plan=api("treasurer","prepare",{"id":request["id"]})
        net=cfg.networks["base"]
        before=int(gateway.rpc(net,"eth_getBalance",[dest,"latest"]),16)
        price=max(2_000_000_000,gateway.gas_price(net)*2)
        raw=Account.from_key(wallets["base"]["vault"]["key"]).sign_transaction(plan_terms(plan,price)).raw_transaction
        signed={"raw":"0x"+bytes(raw).hex()}
        h,_=validate_signed(plan,signed)
        require(broadcast(plan,signed,cfg,origin,tokens["treasurer"])==h, "Payout broadcast hash mismatch")
        confirm_until(store,gateway,lambda:api("buyer")["withdrawals"][0]["status"]=="paid")
        require(int(gateway.rpc(net,"eth_getBalance",[dest,"latest"]),16)==before+UNIT, "Recipient did not receive payout")
        require(snapshot("buyer")["base"]=={"available":"1","reserved":"0"},"Withdrawal accounting incorrect")
        with store.transaction(False) as db:report=audit(db)
        result = {"result":"PASS","network":"isolated Besu acceptance only","base_deposit_hash":base_tx,
                  "quote_deposit_hash":quote_tx,"payout_hash":h,"journal":report}
        pending = LAB / ("report-" + instance + ".tmp")
        pending.write_text(json.dumps(result, indent=2), encoding="utf-8")
        pending.replace(LAB / ("passed-" + instance + ".json"))
        print(json.dumps(result, indent=2))
    finally:
        server.shutdown();server.server_close();thread.join()


if __name__=="__main__":
    main()
