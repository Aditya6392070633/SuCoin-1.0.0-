"""Render a Besu QBFT genesis from PUBLIC inputs only. Never holds validator keys."""
import argparse
import json
from pathlib import Path

from exchange.config import MAX_UINT, address, exact, require


def rlp(value):
    if isinstance(value, list):
        payload, prefix = b"".join(rlp(item) for item in value), 0xc0
    else:
        payload, prefix = value, 0x80
        if len(payload) == 1 and payload[0] < 0x80:
            return payload
    if len(payload) < 56:
        return bytes([prefix + len(payload)]) + payload
    length = len(payload).to_bytes((len(payload).bit_length() + 7) // 8, "big")
    return bytes([prefix + 55 + len(length)]) + length + payload


def render(manifest):
    exact(manifest, ["chain_id", "validators", "allocation_wei", "timestamp", "block_period"])
    chain = manifest["chain_id"]
    require(type(chain) is int and 1024 <= chain < 2**53, "Choose a distinct private chain ID")
    require(type(manifest["timestamp"]) is int and 0 < manifest["timestamp"] < 2**32, "Invalid genesis time")
    require(type(manifest["block_period"]) is int and 2 <= manifest["block_period"] <= 60, "Invalid block period")
    vals = sorted(address(v) for v in manifest["validators"])
    require(4 <= len(vals) <= 64 and len(set(vals)) == len(vals), "Provide four or more distinct validator addresses")
    alloc = {}
    for addr, s in manifest["allocation_wei"].items():
        a = address(addr)
        require(a not in alloc and isinstance(s, str) and s.isascii() and s.isdigit()
                and len(s) <= 78 and 0 < int(s) <= MAX_UINT, "Invalid genesis allocation")
        alloc[a] = {"balance": hex(int(s))}
    require(alloc and sum(int(x["balance"],16) for x in alloc.values()) <= MAX_UINT, "Review supply")
    extra = rlp([bytes(32), [bytes.fromhex(v[2:]) for v in vals], [], b"", []])
    # Berlin and London active from genesis; regular gas fees apply.
    return {"config": {"chainId": chain, "berlinBlock": 0, "londonBlock": 0,
                       "qbft": {"blockperiodseconds": manifest["block_period"], "epochlength": 30000,
                                "requesttimeoutseconds": 2 * manifest["block_period"]}},
            "nonce": "0x0", "timestamp": hex(manifest["timestamp"]), "gasLimit": hex(30_000_000),
            "baseFeePerGas": "0x3b9aca00", "difficulty": "0x1",
            "mixHash": "0x63746963616c2062797a616e74696e65206661756c7420746f6c6572616e6365",
            "extraData": "0x" + extra.hex(), "coinbase": "0x" + "00"*20, "alloc": alloc}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("manifest", type=Path)
    p.add_argument("output", type=Path)
    args = p.parse_args()
    genesis = render(json.loads(args.manifest.read_text()))
    with args.output.open("x", encoding="utf-8") as f:
        json.dump(genesis, f, indent=2)
    print("Genesis written. Independently verify the allocation and genesis block hash with every operator.")
