const el = id => document.getElementById(id);
let token = "", account = null, working = false, viewVersion = 0;
function message(text, error = false) {
  el("message").textContent = text;
  el("message").hidden = !text;
  el("message").className = error ? "error" : "";
}
async function request(path, payload, key) {
  const headers = {Authorization: "Bearer " + token};
  if (payload) Object.assign(headers, {"Content-Type": "application/json", "Idempotency-Key": key});
  const reply = await fetch(path, {method: payload ? "POST" : "GET", headers,
    body: payload ? JSON.stringify(payload) : undefined, cache: "no-store"});
  const data = await reply.json();
  if (!reply.ok) throw Error(data.error || "Request failed");
  return data;
}
function tag(name, text, cls) {
  const node = document.createElement(name);
  if (text !== undefined) node.textContent = String(text);
  if (cls) node.className = cls;
  return node;
}
function table(id, labels, rows, empty) {
  const box = el(id); box.replaceChildren(); box.className = "grid-table";
  if (!rows.length) { box.append(tag("p", empty, "empty")); return; }
  const table = tag("table"), head = table.createTHead().insertRow(), body = table.createTBody();
  labels.forEach(s => head.append(tag("th", s)));
  for (const vals of rows) {
    const row = body.insertRow();
    vals.forEach(v => {
      const cell = row.insertCell();
      if (v instanceof Node) cell.append(v);
      else { cell.textContent = String(v); if (String(v).startsWith("0x")) cell.className = "addr"; }
    });
  }
  box.append(table);
}
function confirmAction(title, text) {
  const d = el("review"); el("review-title").textContent = title; el("review-text").textContent = text;
  d.returnValue = ""; d.showModal();
  return new Promise(resolve => d.addEventListener("close", () => resolve(d.returnValue === "confirm"), {once:true}));
}
async function act(fn) {
  if (working) return;
  working = true;
  try { await fn(); } catch (e) { message(e.message, true); } finally { working = false; }
}
async function command(op, data) {
  const payload = JSON.stringify([account.user, op, data]);
  const salt = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(payload))),
    n => n.toString(16).padStart(2,"0")).join("");
  const slot = "bw.intent." + salt;
  let key = sessionStorage.getItem(slot);
  if (!key) { key = crypto.randomUUID(); sessionStorage.setItem(slot, key); }
  const result = await request("/api/commands/" + op, data, key);
  sessionStorage.removeItem(slot);
  return result;
}
async function refresh() {
  const v = ++viewVersion;
  const data = await request("/api/account");
  if (v !== viewVersion || !token) return;
  account = data; render();
}
function btn(label, handler) {
  const b = tag("button", label, "small-btn");
  b.onclick = () => act(handler);
  return b;
}
function confirmCommand(op, payload, title, detail) {
  return async () => {
    if (!await confirmAction(title, detail)) return;
    const result = await command(op, payload);
    if (op === "prepare") {
      el("plan").hidden = false; el("plan").textContent = "Pass this exact intent to your custody signer.\n" + JSON.stringify(result, null, 2);
    }
    message("Recorded " + (result.status || "signing intent") + " for request #" + (result.id || result.withdrawal_id) + ".");
    await refresh();
  };
}
function destinations() {
  const nodes = account.destinations.filter(x => x.asset === el("withdraw-form").elements.asset.value);
  const dest = el("destination"), old = dest.value; dest.replaceChildren();
  if (!nodes.length) dest.append(new Option("No approved destination", ""));
  for (const item of nodes) {
    const opt = new Option(item.address, item.address);
    opt.disabled = item.valid_from > Math.floor(Date.now()/1000);
    if (opt.disabled) opt.text += " (cooling down)";
    dest.append(opt);
  }
  if (nodes.some(x => x.address === old)) dest.value = old;
}
function render() {
  const a = account, n = a.networks, base = n.base.symbol, quote = n.quote.symbol, customer = a.role === "customer";
  el("signin").hidden = true; el("desk").hidden = false; el("logout").hidden = false;
  el("context").textContent = a.user + " · " + a.role; el("pair").textContent = base + " / " + quote;
  el("chain-status").replaceChildren();
  for (const x of Object.values(n)) {
    const box = tag("div", undefined, "chain" + (x.ready ? "" : " wait"));
    box.append(tag("strong", x.symbol + " · " + (x.halted ? "Halted" : x.ready ? "Settling" : "Waiting for sync")),
      tag("small", "Chain " + x.chain_id + " · settled block " + (x.height ?? "pending")));
    el("chain-status").append(box);
  }
  el("portfolio").hidden = el("customer").hidden = !customer;
  el("ops").hidden = customer;
  table("book", ["Side", "Price ("+quote+")", "Open ("+base+")"],
    [...a.book.sell.slice(0,10).reverse(), ...a.book.buy.slice(0,10)].map(o => [tag("span", o.side, o.side),o.price,o.remaining]), "No open orders.");
  table("trades", ["Fill", "Price ("+quote+")", "Quantity ("+base+")"], a.trades.slice(0,12).map(t => [t.id,t.price,t.quantity]), "No trades have settled.");
  if (customer) {
    el("balances").replaceChildren();
    for (const [side, balance] of Object.entries(a.balances)) {
      const box = tag("div", undefined, "balance");
      box.append(tag("small",n[side].symbol + " available"),tag("b",balance.available),tag("small",balance.reserved+" reserved"));
      el("balances").append(box);
    }
    for (const s of document.querySelectorAll("select.asset")) {
      const old = s.value; s.replaceChildren(new Option(base,"base"),new Option(quote,"quote")); s.value = old || "base";
    }
    destinations();
    el("quantity-label").firstChild.textContent = "Quantity ("+base+")";
    el("price-label").firstChild.textContent = "Price ("+quote+" per "+base+")";
    el("routing").textContent = base+" · "+n.base.vault+"\n"+quote+" · "+n.quote.vault+"\nAccount tag: "+a.deposit_tag;
    table("deposits", ["Asset","Amount","Block","Transaction"], a.deposits.map(d => [n[d.asset].symbol,d.amount,d.height,d.hash]), "Confirmed tagged deposits appear here.");
    table("orders", ["Order","Side","Price","Remaining","Status","Action"], a.orders.map(o => [
      o.id,o.side,o.price,o.remaining,o.status,o.status === "open" ? btn("Cancel",confirmCommand("cancel-order",{id:o.id},"Cancel order #"+o.id,"Release the unfilled amount.")) : "—"]), "No orders yet.");
  } else {
    table("events",["Event","Actor","Action","Details"],a.events.slice(0,20).map(e=>[e.id,e.actor,e.kind,e.detail]),"No operator events.");
  }
  table("withdrawals",["ID","Amount","Destination","State","Approvals","Action"],a.withdrawals.map(w=>{
    let action="—";
    const detail=w.amount+" "+n[w.asset].symbol+"\nTo "+w.address+"\nOwner: "+w.owner;
    if (customer && ["requested","approved"].includes(w.status)) action=btn("Cancel",confirmCommand("cancel-withdrawal",{id:w.id},"Cancel withdrawal #"+w.id,detail));
    if (a.role==="reviewer" && w.status==="requested" && !w.approvals.includes(a.user)) action=btn("Review",confirmCommand("approve",{id:w.id},"Approve withdrawal #"+w.id,detail));
    if (a.role==="treasurer" && ["approved","prepared"].includes(w.status)) action=btn("Signing intent",confirmCommand("prepare",{id:w.id},"Prepare custody signature",detail));
    return [w.id,w.amount+" "+n[w.asset].symbol,w.address,w.status,w.approvals.length+"/2",action];
  }),"No withdrawals.");
}
el("login-form").onsubmit=e=>{ e.preventDefault(); act(async()=>{
  token=el("token").value.trim(); el("token").value=""; await refresh(); message("");
}); };
el("logout").onclick=()=>{ token=""; account=null; ++viewVersion; location.reload(); };
el("refresh").onclick=()=>act(async()=>{await refresh();message("Account refreshed.");});
el("withdraw-form").elements.asset.onchange=destinations;
for (const [form,op] of [["order-form","order"],["withdraw-form","withdraw"]]){
  el(form).onsubmit=e=>{ e.preventDefault(); const data=Object.fromEntries(new FormData(e.target));
    const n=account.networks;
    const summary=op==="order" ? data.side.toUpperCase()+" "+data.quantity+" "+n.base.symbol+" at "+data.price+" "+n.quote.symbol+" per unit" :
      data.amount+" "+n[data.asset].symbol+"\nTo "+data.address;
    act(confirmCommand(op,data,op==="order"?"Place limit order":"Request withdrawal",summary));
  };
}
el("deposit-form").onsubmit=e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));act(async()=>{
  const network=account.networks[data.asset];
  if (!network.ready) throw Error("Settlement is unavailable on this chain.");
  if (!window.ethereum) throw Error("Open this page in an EVM wallet browser, or use the deposit address and account tag shown below.");
  if (!/^(0|[1-9]\d{0,50})(\.\d{1,18})?$/.test(data.amount)) throw Error("Enter a positive amount with up to 18 decimal places.");
  const [whole,frac=""]=data.amount.split("."), atoms=BigInt(whole)*10n**18n+BigInt(frac.padEnd(18,"0"));
  if (atoms<=0n) throw Error("Amount must be positive.");
  const wallet=window.ethereum, checkNetwork=async()=>{
    const chain=await wallet.request({method:"eth_chainId"});
    const genesis=await wallet.request({method:"eth_getBlockByNumber",params:["0x0",false]});
    if (BigInt(chain)!==BigInt(network.chain_id)||genesis.hash.toLowerCase()!==network.genesis) throw Error("Select the configured "+network.symbol+" network in your wallet.");
  };
  await checkNetwork();
  if (!await confirmAction("Deposit "+network.symbol,data.amount+" "+network.symbol+"\nTo "+network.vault+"\nChain ID "+network.chain_id+"\nTag "+account.deposit_tag)) return;
  const [from]=await wallet.request({method:"eth_requestAccounts"}); await checkNetwork();
  const hash=await wallet.request({method:"eth_sendTransaction",params:[{from,to:network.vault,chainId:"0x"+network.chain_id.toString(16),value:"0x"+atoms.toString(16),data:account.deposit_tag}]});
  message("Submitted "+hash+". Credit appears after confirmation and reconciliation.");
});};
setInterval(()=>{ if(token && account && !working && !el("review").open) refresh().catch(e=>message(e.message,true)); },12000);
