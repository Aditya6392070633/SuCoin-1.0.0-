# Verification record

## Exercised on 18 November 2026

| Check | Observed result |
| --- | --- |
| Python 3.12.14 and SQLite 3.53.1, `python3 run.py test` | 46 passed, zero failed, zero skipped. The names and output from the run are in [test-results.txt](test-results.txt). |
| End-to-end application processes | The test starts two loopback JSON-RPC fixture servers, a separate exchange CLI, the HTTP API and a persistent database. It submits an order over HTTP and reads the matching reserve and auditor report through separate processes. |
| Money and failure handling | Covered deposit confirmation, duplicate scans, missing or contradictory receipts, same-block deposits, chain identity, unassigned deposits, reserve drift, price-time priority and partial fills, concurrent spending, order retry, cancellation, two distinct approvers, gas caps, mismatched and failed payouts, account access and revocation. |
| Database recovery | Backed up an active SQLite ledger holding a partially reserved balance, opened the restored copy, resumed both watchers and compared the full audit and customer balance. |
| Source and browser assets | Python compilation and Node.js JavaScript syntax checks passed. The HTML has 31 unique IDs. All 30 literal element lookup targets in the JavaScript resolve. Both operator JSON templates parsed. |

The wallet, block and receipt fixtures used during the 46 tests do not produce blockchain signatures or exercise Besu consensus. No public or customer funds moved.

## Checks supplied for the target environment

| Environment | How to run it and what to retain |
| --- | --- |
| Two isolated Besu networks | `py -3 run.py start` on a workstation with Docker. A successful run records two signed deposits, one confirmed signed withdrawal, the recipient balance check and the reconciled journal in `runtime/lab/passed-*.json`. The exchange console then opens for use. |
| PostgreSQL 16 | The `journal` CI job runs the same test suite using independent disposable schemas. The recovery case uses `pg_dump` and a transactional `pg_restore` to reconstruct the ledger snapshot. Production point-in-time recovery and failover also need rehearsal. |
| External signing | Install `network/requirements.txt` and run `python -m unittest ops.signer_checks -v`. Checks actual signature recovery and rejection of modifications to the approved transaction. Repeat with the custodian selected for live operations. |
| Browser and mobile | Install Playwright and Chromium, then run `python -m unittest ops.browser_checks -v`. It checks login, role visibility, order confirmation and cancellation using the real HTTP service, and horizontal overflow at 320, 390, 768 and 1440 pixels. This is in the CI workflow. |
| Independent chain and Ethereum L1 | Use `python -m ops.commission /path/to/config.json` to compare each network's primary and witness. Follow the operator-funded round trip in [COMMISSIONING.md](COMMISSIONING.md). Retain real receipts, customer journals, reserve reconciliations and a restore record before opening public enrollment. |

The build environment had no Docker engine, PostgreSQL server/client tools or Ethereum signing dependency. Chromium's required local socket was blocked. The Besu, PostgreSQL, signature-recovery and browser jobs have no recorded pass in this delivery. Independent security review, performance under production load, live custody, public deployment and Indian regulatory registration have not been performed.
