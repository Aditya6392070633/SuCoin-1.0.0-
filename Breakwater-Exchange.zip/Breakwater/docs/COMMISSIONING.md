# Commissioning guide

The Windows launcher provisions an isolated acceptance environment. A public deployment needs its own operator-approved genesis, custody system, live node endpoints and operating entity. Publishing the web files alone serves no exchange API.

## 1. Agree on network ownership and assets

Choose a globally distinct chain ID, asset symbol, genesis time, authorized allocation (in the smallest unit, 10^18 per coin), validator operators, payout limits and supported quote chain. The lab IDs 774601 and 774602 are for isolated rehearsals. Each validator needs its own key, an independently secured host and a private transport path to its peers. Four QBFT validators can tolerate one faulty validator under the consensus assumptions. If two stop voting, block production can stop. A single operator controlling all validator keys can control the network.

Use a treasury or MPC custodian to generate a **separate ordinary account address on each settlement network**. Require independent authorization and fee/recipient/nonce policies in the custody system itself. The exchange's two approvals cannot constrain someone who already controls a vault key. Keep operator capital separate from customer liabilities and establish a policy for gas reserves. Customer balances must remain fully covered.

## 2. Build and verify a separate genesis

On each independently operated validator, generate its node key using the official Besu tooling or its supported security module. Export its public address and uncompressed peer public key. Collect only those public values centrally. Derive/import validation keys through your selected key management procedure. A validator restart must recover its original identity.

Copy `ops/genesis.template.json`, replace all sample fields with reviewed public values, and render it:

```sh
python -m network.genesis ceremony.public.json genesis.json
```

The generator refuses to overwrite an existing genesis. Four distinct public validator addresses are required. Supply is created from the explicit genesis allocations. There is no application mint or faucet endpoint. The settings enable native transfers and ordinary gas fees. Review the chain fork schedule whenever changing asset or EVM requirements.

Distribute the identical genesis file over an authenticated channel. Install the reviewed Besu release on each validator host. Configure `ops/val-config.toml` for local paths and generate `static-nodes.json` from the operators' public peer keys and private network addresses. Its format is a JSON array of strings such as `enode://<128-hex-uncompressed-key-without-04>@<private-host>:30303`. Allow peer traffic only across approved links. An independently secured full node can serve RPC to the exchange over authenticated, encrypted private infrastructure. Keep admin and validator-vote RPC methods private.

```sh
besu --config-file=/etc/breakwater/val-config.toml
```

Every operator independently retrieves block zero and records its hash and the opening allocation. For external network verification, compare nodes from separate control domains. At minimum rehearse validator loss/recovery, a fresh node sync and a restore without double-running one validator identity. Review image digests and scan transitive dependencies before a release. The lab pins a Besu release tag; an operator release should pin a verified image digest.

## 3. Commission the exchange ledger

Use a fresh PostgreSQL database and a secret manager. The WSGI process, worker and CLI must use the identical configuration and database. SQLite WAL is available for a single-machine rehearsal. A network filesystem is unsuitable for its WAL database. All money writes are serialized, including on PostgreSQL. Measure expected trading volume and journal growth before setting capacity commitments.

Copy `ops/config.template.json` to a private path. Fill the true chain IDs, independently verified genesis and opening checkpoint hashes, per-chain custody EOAs, withdrawal and gas caps. The commissioned profile requires a witness for both networks and PostgreSQL for the exchange. Use `qbft` for the independent QBFT chain. Use `finalized` for Ethereum L1. Both nodes for each asset must serve full historical blocks, receipts, code and balances at the opening checkpoint and subsequent heights. The lab uses full sync and Forest state storage on each RPC node. An external provider must support these historical queries. Additional L2 posting fees require a separate adapter.

Choose an opening checkpoint **before accepting the first customer deposit**. Its on-chain vault balance becomes operator opening capital. To migrate customers from another exchange, design and independently reconcile an opening-liability migration before binding the ledger. Deploying against a pre-funded customer vault and treating its entire balance as capital would misstate liabilities.

Set these variables through your service or secret manager. The placeholders below describe their purpose:

```text
BREAKWATER_CONFIG=/etc/breakwater/exchange.json
BREAKWATER_DATABASE_URL=postgresql://<service-role>:<secret>@<db-host>/<database>?sslmode=verify-full
BREAKWATER_BASE_RPC=<private primary RPC URL>
BREAKWATER_BASE_WITNESS_RPC=<independent base RPC URL>
BREAKWATER_QUOTE_RPC=<private quote RPC URL>
BREAKWATER_QUOTE_WITNESS_RPC=<independent quote RPC URL>
```

The preflight reads chain identity, opening hashes, vault balances, account code and a common confirmed head from two nodes per asset. It does not submit transactions. Verify both providers independently because two URLs from one provider share a trust boundary.

```sh
python -m pip install -r ops/requirements.txt
python -m ops.commission /etc/breakwater/exchange.json
python -m exchange init
python -m exchange sync
python -m exchange status
python -m exchange audit
```

Initialization binds the database to both chain identities, custody addresses, finality policies and opening checkpoints. Run a **single active watcher** per deployment. A read-only RPC is sufficient for the exchange service itself. Shut down the watcher before restoring data.

```sh
python -m exchange worker
```

Run the web API under a service manager on Linux in a separate process:

```sh
gunicorn --bind 127.0.0.1:8080 --workers 2 --threads 4 --timeout 40 exchange.wsgi:app
```

Use a TLS gateway such as the example in `ops/nginx.conf.example`. Rate-limit requests, enforce staff MFA, isolate reviewer and treasury access and restrict the CLI/database to approved operators. Use a separate DB owner for schema installation. Service roles need specific data permissions; deny DDL, TRUNCATE and changes to append-only history in runtime roles. A DB superuser could alter stored records, so retain externally protected, timestamped audit exports. A public consumer signup portal, identity verification, sanctions/transaction monitoring, fraud reviews, case management and fiat integrations are operator integrations, not included services.

## 4. Onboard customers and approvers

Verify the customer and its business eligibility under the operator's policy before issuing an account. Give each person their own access token through your in-house credential channel. Enroll reviewers and treasurers separately. External staff identity enforcement and hardware-backed MFA should make shared credentials impractical.

```sh
python -m exchange enroll customerA customer
python -m exchange enroll officerA reviewer
python -m exchange enroll officerB reviewer
python -m exchange enroll treasuryOfficer treasurer
python -m exchange enroll financeAudit auditor
python -m exchange allow-address customerA base <independently-verified-destination>
```

The raw token is printed once. The database stores only its SHA-256 digest. Rotate with `python -m exchange rotate NAME`. Revoke API access with `python -m exchange revoke NAME`. Revocation is a credential operation. For an account investigation, separately review open orders, reserved withdrawals and any signed but unbroadcast transactions. Register a destination through an independently authenticated workflow. The commissioned template specifies a 24-hour cooldown. Define per-customer aggregate risk limits and integrate them with any live order/withdrawal policy. The bundled transaction cap applies per withdrawal.

## 5. Deposit, trade and withdraw

A logged-in customer sees a routing tag and custody addresses. For an inbound native transfer the data field must contain exactly the customer's 32 bytes. Sending through a service that omits the data field results in unassigned funds. Only direct successful native transactions are supported. Contract-based internal transfers and unexpected fee/income effects can cause a reserve mismatch, which pauses new financial activity. Crypto deposits may arrive on-chain even while a gateway is paused. Continue monitoring the vaults.

To add operator gas capital after opening, transfer the native asset to the corresponding vault using 32 bytes of `ff` as transaction data. This credits the operator reserve. The system never adds an internal fiat balance. Use the console for order entry and withdrawal review. A withdrawal is reserved first, approved twice, and assigned a single treasury nonce. Only one prepared withdrawal per network can be outstanding. Cancelling is possible before preparation. A pending external transfer keeps the reservation intact.

Export the approved plan on an authenticated treasury workstation. Install `network/requirements.txt` on the separate signing/broadcast tools. For a vendor-controlled MPC/HSM, sign the exact **legacy EIP-155** transfer from the plan, with the specified nonce and gas limit and a gas price below the ceiling. Place the resulting signed hex in a file such as `{"raw":"0x…"}`. No custody private key belongs on the HTTP or ledger host.

```sh
python -m ops.custody export 51 payout-51.json --exchange https://your-exchange-host
python -m ops.custody verify payout-51.json signed-51.json
python -m ops.custody broadcast payout-51.json signed-51.json --config /etc/breakwater/exchange.json --exchange https://your-exchange-host
```

For controlled rehearsal, an offline workstation with a compatible encrypted Web3 keystore can produce the signed file using `python -m ops.custody sign payout-51.json encrypted-keystore.json signed-51.json --gas-price-wei YOUR_GAS_PRICE`. The password is entered locally. Independently verify the recipient, amount, fee, network and nonce against both approvals. Retain signed bytes before broadcasting, since a timeout can occur after the node accepted the transaction. Re-query the transaction hash and rebroadcast the exact same signed bytes if needed. A replacement requires the same nonce and matching reviewed terms. The watcher records actual paid/failed status from the canonical receipt.

## 6. Monitor, recover and decide on launch

Monitor `/health/live` (process) and `/health/ready` (both reconciled chains). Also alert on chain halt, lag, missing receipts, low gas capital, unassigned deposits, blocked withdrawals, storage growth and backup age. Implement service-level objectives and on-call ownership. Never interpret a broadcast acknowledgment as proof of payout.

| Event | Operator action |
| --- | --- |
| RPC delay, stale head or receipt unavailable | Investigate both providers, restore healthy archival access and let the watcher replay from its cursor. Orders resume only after both watchers are current. |
| Previously settled block hash changes, or two nodes disagree | Halt customer-facing activity and the signer, preserve evidence from independent nodes and investigate the validator or provider incident. |
| Vault balance differs from the journal, or an unrecognized payout appears | Isolate custody, retain signed intents, block data and external custody logs, then reconcile at the exact checkpoint. Fix through a separately reviewed correction/migration. Do not clear a halt or edit balances to force readiness. |
| Deposit lacks its customer tag | Keep it in the unassigned account. Independently verify ownership and the original chain transfer, then arrange an audited two-person recovery. No automatic attribution is provided. |
| Database loss | Stop writers and signer, restore snapshot and WAL into an isolated environment, replay journal, verify pending signed nonces at the custody provider, catch up from both nodes and compare all liabilities and actual reserves before returning to service. |

A restored database **cannot reconstruct later off-chain trades, approvals or customer intents from the blockchain**. PostgreSQL continuous WAL archiving, encrypted offsite backups and a tested recovery point objective are essential. Record how much committed state the business can lose, rehearse point-in-time restore and confirm audit exports. The bundled local drill backs up and restores SQLite. Queue reconstruction and live HSM failover need operational tests.

Before taking public deposits, run all target-host acceptance gates, have separate reviewers assess custody, network and ledger code and operating practices, and commission the external financial controls. In India, a business providing covered VDA exchange/transfer/safekeeping services for others can fall under PMLA reporting-entity obligations. Have qualified Indian counsel determine the exact scope and complete applicable FIU-IND registration and AML/KYC/reporting arrangements before onboarding paying customers. Keep track of jurisdiction, tax/accounting, client disclosures and handling of customer assets.

## 7. Verify one operator-funded round trip

After the custody and security reviews and your legal assessment, keep public enrollment closed. Use two operator-controlled customer identities and a fresh approved recipient under operator control. Use a small amount of your own funds that you can afford to lose. Keep enough separate operator capital in each vault to cover network fees. The opening checkpoint must precede the two test deposits. Never reuse a workstation rehearsal key for this stage.

Record the opening balances from both nodes. Send **one tagged deposit on each real settlement network** through the wallet form. Check the two hashes independently, compare the credited amounts and run the journal audit. Place a crossing buy and sell, request a small withdrawal, obtain both reviewer approvals, and have the commissioned custodian sign. Retain the approved plan, actual signed hash and final receipt. Verify the recipient balance, gas paid, open liabilities and vault balances at a common finalized height. Restore the database to an isolated host and verify the same journal and custody balances there. Record operator sign-off and treat any discrepancy as a failed pilot.

## 8. Budget the launch

| Stage | What to price |
| --- | --- |
| On your existing Windows PC | The isolated rehearsal incurs no public-chain gas or cloud bill. Allow for local hardware, electricity, internet and any applicable Docker Desktop subscription. |
| Private hosted rehearsal | As an illustration, four 4 GiB, 2-vCPU Basic VMs at DigitalOcean's published $24 per month come to $96 per month for validator compute alone. Profile memory, disk growth and traffic before sizing. Include application hosts, settlement RPC, PostgreSQL, storage, backups and monitoring separately. The bundled dual-network rehearsal starts eight validators. |
| Customer-funds launch | Get scoped quotes for custody and key recovery, independent security review and remediation, legal and registration work, customer verification, transaction monitoring, support and on-call response. Separately budget market liquidity and operator gas reserves by currency. The source project has no fixed all-in launch price. |

Official references:

- [Besu QBFT consensus and genesis](https://docs.besu-eth.org/private-networks/how-to/configure/consensus/qbft)
- [Besu independent network setup](https://docs.besu-eth.org/private-networks/tutorials/qbft)
- [Besu archive node storage formats](https://docs.besu-eth.org/public-networks/concepts/data-storage-formats)
- [Ethereum JSON-RPC methods](https://ethereum.org/developers/docs/apis/json-rpc)
- [FIU-IND current VDA guidance and registration circulars](https://fiuindia.gov.in/files/downloads/downloads.html)
- [DigitalOcean published VM pricing](https://www.digitalocean.com/pricing/droplets)
