"""Breakwater spot exchange and native-chain settlement service."""
