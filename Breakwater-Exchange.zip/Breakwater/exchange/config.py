import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

ASSETS = ("base", "quote")
UNIT = 10**18
SCALE = 10**6
LOT = UNIT // SCALE
COST_UNIT = UNIT // (SCALE * SCALE)
MAX_UINT = 2**256 - 1
CAPITAL_TAG = "0x" + "ff" * 32
ZERO = "0x" + "0" * 40
IDENTIFIER = re.compile(r"[A-Za-z][A-Za-z0-9_-]{1,47}\Z")


class Fault(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def require(condition, message, status=400):
    if not condition:
        raise Fault(message, status)


def address(value):
    require(isinstance(value, str) and re.fullmatch(r"0x[0-9a-fA-F]{40}", value)
            and value.lower() != ZERO, "Enter a nonzero EVM address")
    return value.lower()


def block_hash(value):
    require(isinstance(value, str) and re.fullmatch(r"0x[0-9a-fA-F]{64}", value),
            "Invalid 32-byte hash")
    return value.lower()


def amount(value, places=18):
    require(isinstance(value, str) and len(value) < 82
            and re.fullmatch(r"(0|[1-9][0-9]*)(\.[0-9]{1," + str(places) + "})?", value),
            f"Use a decimal string with at most {places} fractional digits")
    whole, _, frac = value.partition(".")
    n = int(whole) * 10**places + int(frac.ljust(places, "0"))
    require(0 < n <= MAX_UINT, "Amount is outside the supported range")
    return n


def display(value, places=18):
    value = int(value)
    if value < 0:
        return "-" + display(-value, places)
    whole, frac = divmod(value, 10**places)
    return f"{whole}.{frac:0{places}d}".rstrip("0").rstrip(".")


def exact(data, names):
    require(isinstance(data, dict) and set(data) == set(names), "Missing or unexpected fields")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


@dataclass(frozen=True)
class Network:
    asset: str
    symbol: str
    chain_id: int
    genesis: str
    rpc: str
    vault: str
    anchor: int
    anchor_hash: str
    finality: str
    confirmations: int
    max_withdrawal: int
    gas_price_cap: int = 100_000_000_000
    witness_rpc: str = ""

    def identity(self):
        return [self.asset, self.symbol, self.chain_id, self.genesis, self.vault,
                self.anchor, self.anchor_hash, self.finality, self.confirmations, bool(self.witness_rpc)]


@dataclass
class Settings:
    networks: dict
    database: str
    allowlist_delay: int
    max_age: int = 120
    profile: str = "lab"

    @classmethod
    def load(cls, filename):
        path = Path(filename).resolve()
        data = json.loads(path.read_text(encoding="utf-8"))
        profile = data.get("profile", "lab")
        require(profile in ("lab", "commissioned"), "Use a lab or commissioned profile")
        networks = {}
        for asset in ASSETS:
            row = data["networks"][asset]
            rpc = os.environ.get(f"BREAKWATER_{asset.upper()}_RPC", row["rpc"])
            url = urlsplit(rpc)
            require(url.scheme == "https" or (url.scheme == "http" and url.hostname in
                    {"localhost", "127.0.0.1", "::1"}), "Use HTTPS or loopback HTTP for RPC")
            require(url.hostname and not url.username and not url.password and not url.fragment,
                    "Use an RPC URL without userinfo or a fragment")
            if profile == "lab":
                require(url.hostname in ("127.0.0.1", "localhost", "::1"),
                        "External networks require the commissioned profile")
            mode = row["finality"]
            require(mode in ("qbft", "finalized"), "Unsupported finality policy")
            depth = row.get("confirmations", 2)
            require(type(depth) is int and 1 <= depth <= 1024, "Invalid confirmation depth")
            require(type(row["chain_id"]) is int and 0 < row["chain_id"] < 2**53, "Invalid chain ID")
            if row["chain_id"] == 1:
                require(mode == "finalized", "Ethereum L1 requires finalized checkpoints")
            require(type(row["anchor_height"]) is int and row["anchor_height"] >= 0, "Invalid anchor")
            require(re.fullmatch(r"[A-Z][A-Z0-9]{1,9}", row["symbol"]), "Invalid symbol")
            cap = row.get("gas_price_cap_wei", "100000000000")
            require(isinstance(cap, str) and re.fullmatch(r"[1-9][0-9]{0,18}", cap), "Invalid fee cap")
            witness = os.environ.get(f"BREAKWATER_{asset.upper()}_WITNESS_RPC", row.get("witness_rpc", ""))
            if profile == "commissioned":
                require(witness, "Commissioned settlement requires a second independently operated RPC per asset")
            if witness:
                w = urlsplit(witness)
                require(w.hostname and not w.username and not w.password and not w.fragment
                        and (w.scheme == "https" or (w.scheme == "http" and w.hostname in ("127.0.0.1", "localhost", "::1")))
                        and witness != rpc, "Configure a distinct trusted witness RPC")
            networks[asset] = Network(asset, row["symbol"], row["chain_id"], block_hash(row["genesis"]),
                                      rpc, address(row["vault"]), row["anchor_height"],
                                      block_hash(row["anchor_hash"]), mode, depth,
                                      amount(row["max_withdrawal"]), int(cap), witness)
        require(networks["base"].chain_id != networks["quote"].chain_id and
                networks["base"].genesis != networks["quote"].genesis,
                "The two settlement networks need distinct chain IDs and genesis hashes")
        require(networks["base"].symbol != networks["quote"].symbol, "Symbols must differ")
        delay = data.get("allowlist_delay_seconds", 86400)
        max_age = data.get("max_sync_age_seconds", 120)
        require(type(delay) is int and 0 <= delay <= 604800 and type(max_age) is int
                and 10 <= max_age <= 300, "Invalid time policy")
        database = os.environ.get("BREAKWATER_DATABASE_URL") or str(path.parent / data.get("sqlite_file", "exchange.sqlite"))
        return cls(networks, database, delay, max_age, profile)
