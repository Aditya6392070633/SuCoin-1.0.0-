import time

from .config import ASSETS, COST_UNIT, LOT, address, amount, display, exact, require


def available(name):
    return name + ":available"


def locked(name, kind, ident):
    return f"{name}:{kind}:{ident}"


def order_view(row):
    return {k: row[k] for k in ("id", "side", "status")} | {
        "quantity": display(row["lots"], 6), "remaining": display(row["remaining"], 6),
        "price": display(row["price"], 6)}


def trade_view(row):
    return {"id": row["id"], "quantity": display(row["lots"], 6), "price": display(row["price"], 6),
            "time": row["created"], "maker_order": row["maker"], "taker_order": row["taker"]}


def create_order(db, cfg, owner, data):
    exact(data, ["side", "quantity", "price"])
    db.operational(cfg.max_age)
    side = data["side"]
    require(side in ("buy", "sell"), "Side must be buy or sell")
    qty, limit = amount(data["quantity"], 6), amount(data["price"], 6)
    require(max(qty, limit) <= 10**15, "Order exceeds market precision limits")
    require(db.one("SELECT COUNT(*) AS n FROM orders WHERE owner=? AND status='open'", owner)["n"] < 128,
            "Maximum open orders per account reached")
    ident = db.next_id()
    db.sql("INSERT INTO orders VALUES (?,?,?,?,?,?,?)", (ident, owner, side, limit, qty, qty, "open"))
    pocket = locked(owner, "order", ident)
    asset, reserve = ("base", qty * LOT) if side == "sell" else ("quote", qty * limit * COST_UNIT)
    db.move(asset, available(owner), pocket, reserve, f"order:{ident}")
    if side == "buy":
        query = "SELECT * FROM orders WHERE side='sell' AND status='open' AND price<=? ORDER BY price ASC,id ASC LIMIT 513"
    else:
        query = "SELECT * FROM orders WHERE side='buy' AND status='open' AND price>=? ORDER BY price DESC,id ASC LIMIT 513"
    remaining = qty
    for i, maker in enumerate(db.rows(query, limit)):
        if remaining == 0:
            break
        require(i < 512, "Too many fills in one order. Use a smaller order.", 409)
        require(maker["owner"] != owner, "Order would trade against your own order", 409)
        filled = min(remaining, maker["remaining"])
        trade_id = db.next_id()
        ref = f"trade:{trade_id}"
        maker_pocket = locked(maker["owner"], "order", maker["id"])
        if side == "buy":
            buyer, seller = owner, maker["owner"]
            bid, ask, bid_price = pocket, maker_pocket, limit
        else:
            buyer, seller = maker["owner"], owner
            bid, ask, bid_price = maker_pocket, pocket, maker["price"]
        db.move("base", ask, available(buyer), filled * LOT, ref)
        db.move("quote", bid, available(seller), filled * maker["price"] * COST_UNIT, ref)
        improvement = filled * (bid_price - maker["price"]) * COST_UNIT
        if improvement:
            db.move("quote", bid, available(buyer), improvement, ref)
        db.sql("INSERT INTO trades VALUES (?,?,?,?,?,?,?,?)",
               (trade_id, int(time.time()), buyer, seller, maker["id"], ident, filled, maker["price"]))
        left = maker["remaining"] - filled
        db.sql("UPDATE orders SET remaining=?,status=? WHERE id=?", (left, "open" if left else "filled", maker["id"]))
        remaining -= filled
    db.sql("UPDATE orders SET remaining=?,status=? WHERE id=?", (remaining, "open" if remaining else "filled", ident))
    db.event(owner, "order", {"id": ident})
    return order_view(db.one("SELECT * FROM orders WHERE id=?", ident))


def cancel_order(db, owner, ident):
    order = db.one("SELECT * FROM orders WHERE id=? AND owner=?", ident, owner)
    require(order, "Order not found", 404)
    require(order["status"] == "open", "Order is already closed", 409)
    asset = "base" if order["side"] == "sell" else "quote"
    pocket = locked(owner, "order", ident)
    db.move(asset, pocket, available(owner), db.balance(asset, pocket), f"cancel:{ident}")
    db.sql("UPDATE orders SET status='cancelled',remaining=0 WHERE id=?", (ident,))
    db.event(owner, "cancel_order", {"id": ident})
    return {"id": ident, "status": "cancelled"}


def allow_address(db, cfg, owner, asset, dest):
    require(asset in ASSETS, "Unknown asset")
    require(db.one("SELECT name FROM identities WHERE name=? AND role='customer'", owner), "Unknown customer")
    dest = address(dest)
    require(dest != cfg.networks[asset].vault, "Destination is the exchange vault")
    valid = int(time.time()) + cfg.allowlist_delay
    db.sql("INSERT INTO destinations VALUES (?,?,?,?) ON CONFLICT DO NOTHING", (owner, asset, dest, valid))
    db.event("operator", "allow_address", {"owner": owner, "asset": asset, "address": dest})
    return db.one("SELECT * FROM destinations WHERE owner=? AND asset=? AND address=?", owner, asset, dest)


def withdrawal_view(db, row):
    return {k: row[k] for k in ("id", "owner", "asset", "address", "status", "nonce", "tx_hash")} | {
        "amount": display(row["atoms"]),
        "approvals": [a["reviewer"] for a in db.rows(
            "SELECT reviewer FROM approvals WHERE withdrawal=? ORDER BY reviewer", row["id"])]}


def request_withdrawal(db, cfg, owner, data):
    exact(data, ["asset", "amount", "address"])
    db.operational(cfg.max_age)
    asset, dest, n = data["asset"], address(data["address"]), amount(data["amount"])
    require(asset in ASSETS, "Unknown asset")
    require(n <= cfg.networks[asset].max_withdrawal, "Above per-withdrawal policy limit", 409)
    target = db.one("SELECT valid_from FROM destinations WHERE owner=? AND asset=? AND address=?", owner, asset, dest)
    require(target and target["valid_from"] <= int(time.time()), "Destination is missing or still cooling down", 409)
    ident = db.next_id()
    db.move(asset, available(owner), locked(owner, "withdrawal", ident), n, f"withdrawal:{ident}")
    db.sql("INSERT INTO withdrawals VALUES (?,?,?,?,?,'requested',NULL,NULL,NULL)", (ident, owner, asset, dest, str(n)))
    db.event(owner, "request_withdrawal", {"id": ident, "amount_atoms": str(n), "address": dest, "asset": asset})
    return withdrawal_view(db, db.one("SELECT * FROM withdrawals WHERE id=?", ident))


def approve(db, cfg, reviewer, ident):
    db.operational(cfg.max_age)
    row = db.one("SELECT * FROM withdrawals WHERE id=?", ident)
    require(row, "Withdrawal not found", 404)
    require(row["status"] == "requested", "Withdrawal cannot accept approvals", 409)
    require(not db.one("SELECT reviewer FROM approvals WHERE withdrawal=? AND reviewer=?", ident, reviewer),
            "A different reviewer must provide the second approval", 409)
    db.sql("INSERT INTO approvals VALUES (?,?,?)", (ident, reviewer, int(time.time())))
    if db.one("SELECT COUNT(*) AS n FROM approvals WHERE withdrawal=?", ident)["n"] >= 2:
        db.sql("UPDATE withdrawals SET status='approved' WHERE id=?", (ident,))
    db.event(reviewer, "approve_withdrawal", {"id": ident})
    return withdrawal_view(db, db.one("SELECT * FROM withdrawals WHERE id=?", ident))


def cancel_withdrawal(db, owner, ident):
    row = db.one("SELECT * FROM withdrawals WHERE id=? AND owner=?", ident, owner)
    require(row, "Withdrawal not found", 404)
    require(row["status"] in ("requested", "approved"), "A prepared or settled withdrawal cannot be cancelled", 409)
    db.move(row["asset"], locked(owner, "withdrawal", ident), available(owner), int(row["atoms"]), f"cancel-withdrawal:{ident}")
    db.sql("UPDATE withdrawals SET status='cancelled' WHERE id=?", (ident,))
    db.event(owner, "cancel_withdrawal", {"id": ident})
    return {"id": ident, "status": "cancelled"}


def signing_plan(cfg, row):
    n = cfg.networks[row["asset"]]
    return {"withdrawal_id": row["id"], "symbol": n.symbol, "genesis": n.genesis, "gas_price_cap_wei": row["fee_cap"],
            "intent": {"chainId": hex(n.chain_id), "from": n.vault, "to": row["address"],
                       "value": hex(int(row["atoms"])), "nonce": hex(row["nonce"]), "data": "0x", "gas": "0x5208"}}


def prepare(db, cfg, treasurer, ident, gateway):
    db.operational(cfg.max_age)
    row = db.one("SELECT * FROM withdrawals WHERE id=?", ident)
    require(row, "Withdrawal not found", 404)
    if row["status"] == "prepared":
        return signing_plan(cfg, row)
    require(row["status"] == "approved", "Two distinct reviewers must approve first", 409)
    require(not db.one("SELECT id FROM withdrawals WHERE asset=? AND status='prepared'", row["asset"]),
            "Settle the previous signed intent on this chain first", 409)
    net = cfg.networks[row["asset"]]
    gateway.identity(net)
    require(gateway.code(net, row["address"], "latest") == "0x", "Only direct payments to ordinary accounts are supported")
    pending = gateway.nonce(net, "pending")
    require(pending == gateway.nonce(net, "latest"), "Vault already has a pending transaction", 409)
    # No signer should reuse a nonce after a restart or failover.
    prev = db.one("SELECT MAX(nonce) AS n FROM withdrawals WHERE asset=?", net.asset)["n"]
    require(prev is None or pending > prev, "Nonce is already reserved", 409)
    require(gateway.gas_price(net) <= net.gas_price_cap, "Network fees exceed the custody policy cap", 409)
    fee_budget = 21000 * net.gas_price_cap
    require(db.balance(net.asset, "@capital") >= fee_budget, "Fund the operator's network-fee reserve", 409)
    require(gateway.balance(net, "latest") >= int(row["atoms"]) + fee_budget, "Vault cannot fund payout and fee", 409)
    db.sql("UPDATE withdrawals SET status='prepared',nonce=?,fee_cap=? WHERE id=?", (pending, str(net.gas_price_cap), ident))
    db.event(treasurer, "prepare_withdrawal", {"id": ident, "nonce": pending})
    return signing_plan(cfg, db.one("SELECT * FROM withdrawals WHERE id=?", ident))
