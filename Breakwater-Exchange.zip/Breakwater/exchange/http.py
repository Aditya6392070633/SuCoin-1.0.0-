import json
import logging
from http import HTTPStatus
from pathlib import Path
from urllib.parse import urlsplit

from .chain import Conflict, RpcError
from .config import Fault, require

WEB = Path(__file__).resolve().parent.parent / "web"
FILES = {"/": ("index.html", "text/html"), "/app.js": ("app.js", "text/javascript"),
         "/style.css": ("style.css", "text/css")}


def application(service):
    def app(env, start):
        headers = [("Cache-Control", "no-store"), ("X-Content-Type-Options", "nosniff"),
                   ("Referrer-Policy", "no-referrer"), ("X-Frame-Options", "DENY"),
                   ("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")]
        path, method = env.get("PATH_INFO", ""), env.get("REQUEST_METHOD", "")
        mime = "application/json"
        status = 200
        try:
            auth = env.get("HTTP_AUTHORIZATION", "")
            token = auth[7:] if auth.startswith("Bearer ") else ""
            if method == "GET" and path in FILES:
                name, mime = FILES[path]
                body = (WEB / name).read_bytes()
            elif method == "GET" and path == "/health/live":
                body = b'{"process":"up"}'
            elif method == "GET" and path == "/health/ready":
                with service.store.transaction(False) as db:
                    db.operational(service.cfg.max_age)
                body = b'{"settlement":"ready"}'
            elif method == "GET" and path == "/api/account":
                body = json.dumps(service.read(token)).encode()
            elif method == "POST" and path.startswith("/api/commands/"):
                if "HTTP_ORIGIN" in env:
                    origin = urlsplit(env["HTTP_ORIGIN"])
                    require(origin.scheme in ("https", "http") and origin.netloc == env.get("HTTP_HOST"),
                            "Origin mismatch", 403)
                require(env.get("CONTENT_TYPE", "").split(";")[0] == "application/json", "Use JSON", 415)
                length = int(env.get("CONTENT_LENGTH") or 0)
                require(0 < length <= 8192, "Body is empty or too large", 413)
                payload = json.loads(env["wsgi.input"].read(length))
                require(isinstance(payload, dict), "JSON object required")
                result = service.change(token, env.get("HTTP_IDEMPOTENCY_KEY"), path.split("/")[-1], payload)
                body = json.dumps(result).encode()
            else:
                raise Fault("Route not found", 404)
        except Fault as e:
            status, body = e.status, json.dumps({"error": str(e)}).encode()
        except (RpcError, Conflict):
            status, body = 503, b'{"error":"Settlement node unavailable or inconsistent"}'
        except (ValueError, UnicodeError, RecursionError):
            status, body = 400, b'{"error":"Invalid request encoding or value"}'
        except Exception:
            logging.exception("Request failed")
            status, body = 500, b'{"error":"Server error. Check operator logs."}'
        start(f"{status} {HTTPStatus(status).phrase}", headers + [("Content-Type", mime + "; charset=utf-8"), ("Content-Length", str(len(body)))])
        return [body]
    return app
