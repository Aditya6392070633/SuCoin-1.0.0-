import argparse
import json
import os
import sys
import time
from wsgiref.simple_server import make_server

from .chain import Conflict, Gateway, RpcError, sync_one
from .config import ASSETS, Fault, Settings, require
from .http import application
from .market import allow_address
from .service import Service, audit
from .store import Store


def main():
    p = argparse.ArgumentParser(description="Breakwater operator tools")
    p.add_argument("--config", default=os.environ.get("BREAKWATER_CONFIG", "runtime/exchange.json"))
    cmd = p.add_subparsers(dest="command", required=True)
    for name in ("init", "sync", "worker", "audit", "status"):
        cmd.add_parser(name)
    add = cmd.add_parser("enroll")
    add.add_argument("name")
    add.add_argument("role", choices=["customer", "reviewer", "treasurer", "auditor"])
    for op in ("rotate", "revoke"):
        cmd.add_parser(op).add_argument("name")
    allow = cmd.add_parser("allow-address")
    allow.add_argument("customer")
    allow.add_argument("asset", choices=ASSETS)
    allow.add_argument("address")
    serve = cmd.add_parser("serve")
    serve.add_argument("--port", type=int, default=8080)
    args = p.parse_args()
    cfg = Settings.load(args.config)
    store, gateway = Store(cfg), Gateway()
    if args.command == "init":
        store.init()
        print("Schema initialized and network identity pinned.")
        return
    # Every new process verifies the same identity including key custody parameters.
    from .config import canonical
    with store.transaction(False) as db:
        identity = db.one("SELECT value FROM meta WHERE key='identity'")
        require(identity and identity["value"] == canonical([1, [cfg.networks[a].identity() for a in ASSETS]]),
                "Configuration differs from pinned database identity")
    if args.command == "enroll":
        print(store.enroll(args.name, args.role))
    elif args.command == "rotate":
        print(store.rotate(args.name))
    elif args.command == "revoke":
        with store.transaction() as db:
            require(db.one("SELECT name FROM identities WHERE name=?", args.name), "Unknown principal")
            db.sql("UPDATE identities SET enabled=0 WHERE name=?", (args.name,))
            db.event("operator", "revoke", {"name": args.name})
    elif args.command == "allow-address":
        with store.transaction() as db:
            print(json.dumps(allow_address(db, cfg, args.customer, args.asset, args.address)))
    elif args.command in ("sync", "worker"):
        while True:
            failed = False
            for asset in ASSETS:
                try:
                    sync_one(store, cfg.networks[asset], gateway)
                except (Fault, Conflict, RpcError, KeyError, ValueError, TypeError) as err:
                    failed = True
                    print(f"{asset}: {err}", file=sys.stderr, flush=True)
            if args.command == "sync":
                return int(failed)
            time.sleep(2)
    elif args.command == "serve":
        server = make_server("127.0.0.1", args.port, application(Service(store, gateway)))
        print(f"Breakwater console: http://127.0.0.1:{server.server_port}", flush=True)
        server.serve_forever()
    else:
        with store.transaction(False) as db:
            result = audit(db) if args.command == "audit" else db.rows("SELECT * FROM chains ORDER BY asset")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        pass
    except (Fault, OSError, ValueError) as err:
        sys.exit(str(err))
