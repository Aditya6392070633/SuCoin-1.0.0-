CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS identities (
 name TEXT PRIMARY KEY, role TEXT NOT NULL CHECK(role IN ('customer','reviewer','treasurer','auditor')),
 token_hash TEXT UNIQUE NOT NULL, tag TEXT UNIQUE NOT NULL, enabled BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS balances (
 asset TEXT NOT NULL, pocket TEXT NOT NULL, atoms TEXT NOT NULL, PRIMARY KEY(asset,pocket)
);
CREATE TABLE IF NOT EXISTS moves (
 id BIGINT PRIMARY KEY, created BIGINT NOT NULL, asset TEXT NOT NULL, debit TEXT NOT NULL,
 credit TEXT NOT NULL, atoms TEXT NOT NULL, reference TEXT NOT NULL, CHECK(debit <> credit)
);
CREATE TABLE IF NOT EXISTS events (
 id BIGINT PRIMARY KEY, created BIGINT NOT NULL, actor TEXT NOT NULL, kind TEXT NOT NULL, detail TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
 actor TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL, response TEXT NOT NULL, PRIMARY KEY(actor,key)
);
CREATE TABLE IF NOT EXISTS orders (
 id BIGINT PRIMARY KEY, owner TEXT NOT NULL REFERENCES identities(name), side TEXT NOT NULL CHECK(side IN ('buy','sell')),
 price BIGINT NOT NULL CHECK(price > 0), lots BIGINT NOT NULL CHECK(lots > 0), remaining BIGINT NOT NULL CHECK(remaining >= 0),
 status TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS book ON orders(status,side,price,id);
CREATE TABLE IF NOT EXISTS trades (
 id BIGINT PRIMARY KEY, created BIGINT NOT NULL, buyer TEXT NOT NULL, seller TEXT NOT NULL,
 maker BIGINT NOT NULL REFERENCES orders(id), taker BIGINT NOT NULL REFERENCES orders(id),
 lots BIGINT NOT NULL CHECK(lots > 0), price BIGINT NOT NULL CHECK(price > 0)
);
CREATE TABLE IF NOT EXISTS destinations (
 owner TEXT NOT NULL REFERENCES identities(name), asset TEXT NOT NULL, address TEXT NOT NULL, valid_from BIGINT NOT NULL,
 PRIMARY KEY(owner,asset,address)
);
CREATE TABLE IF NOT EXISTS withdrawals (
 id BIGINT PRIMARY KEY, owner TEXT NOT NULL REFERENCES identities(name), asset TEXT NOT NULL,
 address TEXT NOT NULL, atoms TEXT NOT NULL, status TEXT NOT NULL, nonce BIGINT, tx_hash TEXT, fee_cap TEXT,
 UNIQUE(asset,nonce), UNIQUE(asset,tx_hash)
);
CREATE TABLE IF NOT EXISTS approvals (
 withdrawal BIGINT NOT NULL REFERENCES withdrawals(id), reviewer TEXT NOT NULL REFERENCES identities(name),
 created BIGINT NOT NULL, PRIMARY KEY(withdrawal,reviewer)
);
CREATE TABLE IF NOT EXISTS chains (
 asset TEXT PRIMARY KEY, height BIGINT NOT NULL, hash TEXT NOT NULL, last_sync BIGINT NOT NULL,
 halted TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS settlements (
 asset TEXT NOT NULL, hash TEXT NOT NULL, height BIGINT NOT NULL, kind TEXT NOT NULL, owner TEXT NOT NULL,
 atoms TEXT NOT NULL, PRIMARY KEY(asset,hash)
);
