"""Existing-database entry point for a TLS-proxied WSGI process."""
from os import environ
from .chain import Gateway
from .config import ASSETS, Settings, canonical, require
from .http import application
from .service import Service
from .store import Store

cfg = Settings.load(environ["BREAKWATER_CONFIG"])
store = Store(cfg)
with store.transaction(False) as db:
    row = db.one("SELECT value FROM meta WHERE key='identity'")
    require(row and row["value"] == canonical([1, [cfg.networks[a].identity() for a in ASSETS]]), "Database identity mismatch")
app = application(Service(store, Gateway()))
