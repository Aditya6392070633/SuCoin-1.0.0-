"""Watch-only JSON-RPC. A finalized receipt and reconciled vault balance drive settlement."""
import json
import time
import urllib.error
import urllib.request
from dataclasses import replace

from .config import ASSETS, CAPITAL_TAG, Fault, block_hash, require
from .market import available, locked


class RpcError(Exception):
    pass


class Conflict(Exception):
    """A durable settlement invariant or configured network identity was violated."""


def qty(s):
    if not isinstance(s, str) or not s.startswith("0x") or len(s) > 66:
        raise RpcError("RPC quantity is malformed")
    try:
        n = int(s[2:], 16)
    except ValueError as e:
        raise RpcError("Invalid hexadecimal RPC quantity") from e
    if n < 0:
        raise RpcError("RPC quantity must be unsigned")
    return n


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


class Gateway:
    def __init__(self):
        self.opener = urllib.request.build_opener(NoRedirect)

    def rpc(self, net, method, params):
        body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode()
        req = urllib.request.Request(net.rpc, body, {"Content-Type": "application/json"})
        try:
            with self.opener.open(req, timeout=10) as r:
                raw = r.read(16_000_001)
            if len(raw) > 16_000_000:
                raise RpcError("RPC response exceeds size limit")
            msg = json.loads(raw)
            if msg.get("id") != 1 or "result" not in msg or "error" in msg:
                raise RpcError(f"Node did not return a result for {method}")
            return msg["result"]
        except (OSError, ValueError, urllib.error.URLError) as e:
            # Never leak provider credentials embedded in configuration URLs.
            raise RpcError(f"Node unavailable for {method}") from e

    def block(self, net, height, full=False):
        item = self.rpc(net, "eth_getBlockByNumber", [hex(height) if type(height) is int else height, full])
        if not isinstance(item, dict) or not item.get("hash"):
            raise RpcError("Requested block unavailable. Check archival history and finality support")
        return item

    def identity(self, net):
        if qty(self.rpc(net, "eth_chainId", [])) != net.chain_id or self.block(net, 0)["hash"].lower() != net.genesis:
            raise Conflict("RPC chain ID or genesis hash changed")

    def balance(self, net, height):
        tag = hex(height) if type(height) is int else height
        return qty(self.rpc(net, "eth_getBalance", [net.vault, tag]))

    def code(self, net, addr, height):
        return self.rpc(net, "eth_getCode", [addr, hex(height) if type(height) is int else height])

    def nonce(self, net, tag):
        return qty(self.rpc(net, "eth_getTransactionCount", [net.vault, tag]))

    def gas_price(self, net):
        return qty(self.rpc(net, "eth_gasPrice", []))


def checkpoint_age(now, block, limit):
    age = now - qty(block["timestamp"])
    if not -30 <= age <= limit:
        raise RpcError("Chain stopped advancing or clock differs from its node")


def tip(gateway, net, now):
    if gateway.rpc(net, "eth_syncing", []) is not False:
        raise RpcError("Node is downloading chain history")
    latest = gateway.block(net, "latest")
    checkpoint_age(now, latest, 180)
    if net.finality == "qbft":
        return max(0, qty(latest["number"]) - net.confirmations)
    final = gateway.block(net, "finalized")
    checkpoint_age(now, final, 2400)
    return min(qty(final["number"]), qty(latest["number"]) - net.confirmations)


def collect(gateway, net, height):
    block = gateway.block(net, height, True)
    if qty(block["number"]) != height or not isinstance(block.get("transactions"), list):
        raise RpcError("Unexpected block response")
    b_hash = block_hash(block["hash"])
    selected = []
    seen = set()
    for i, tx in enumerate(block["transactions"]):
        sender = tx["from"].lower()
        dest = (tx.get("to") or "").lower()
        if net.vault not in (sender, dest):
            continue
        h = block_hash(tx["hash"])
        if h in seen or tx["blockHash"].lower() != b_hash or qty(tx["blockNumber"]) != height or qty(tx["transactionIndex"]) != i:
            raise Conflict("Inconsistent transaction inclusion")
        seen.add(h)
        receipt = gateway.rpc(net, "eth_getTransactionReceipt", [h])
        if not receipt:
            raise RpcError("Receipt not available yet")
        if (receipt["transactionHash"].lower() != h or receipt["blockHash"].lower() != b_hash
                or qty(receipt["blockNumber"]) != height or qty(receipt["transactionIndex"]) != i):
            raise Conflict("Receipt does not match canonical transaction")
        status = qty(receipt["status"])
        if status not in (0, 1):
            raise RpcError("Unknown receipt status")
        effective = receipt.get("effectiveGasPrice")
        if effective is None:
            effective = tx["gasPrice"]
        fee = qty(receipt["gasUsed"]) * qty(effective)
        if receipt.get("blobGasUsed"):
            fee += qty(receipt["blobGasUsed"]) * qty(receipt["blobGasPrice"])
        selected.append({"hash": h, "from": sender, "to": dest, "ok": status == 1, "data": tx["input"].lower(),
                         "nonce": qty(tx["nonce"]), "value": qty(tx["value"]), "fee": fee})
    balance = gateway.balance(net, height)
    if gateway.code(net, net.vault, height) != "0x":
        raise Conflict("Custody address has contract or delegation code")
    if gateway.block(net, height)["hash"].lower() != b_hash:
        raise Conflict("Finalized block changed while reading receipts and balance")
    return block, selected, balance


def settle(db, net, height, tx):
    vault, asset, h = net.vault, net.asset, tx["hash"]
    value, owner, reason = tx["value"], "", ""
    if tx["from"] == vault:
        if tx["fee"]:
            db.move(asset, "@capital", "@custody", tx["fee"], h + ":fee")
        w = db.one("SELECT * FROM withdrawals WHERE asset=? AND nonce=? AND status='prepared'", asset, tx["nonce"])
        matched = w and tx["to"] == w["address"] and value == int(w["atoms"]) and tx["data"] == "0x"
        kind = "payout"
        if matched:
            owner = w["owner"]
            pocket = locked(owner, "withdrawal", w["id"])
            status = "paid" if tx["ok"] else "failed"
            db.move(asset, pocket, "@custody" if tx["ok"] else available(owner), value, h)
            db.sql("UPDATE withdrawals SET status=?,tx_hash=? WHERE id=?", (status, h, w["id"]))
            db.event("chain", "withdrawal_" + status, {"id": w["id"], "hash": h})
            kind = status
            if tx["fee"] > 21000 * int(w["fee_cap"]):
                reason = "Payout exceeded the approved maximum fee " + h
        else:
            if tx["ok"] and value and tx["to"] != vault:
                db.move(asset, "@capital", "@custody", value, h)
            reason = "Unexpected outgoing vault transaction " + h
            kind = "unknown_outgoing"
    else:
        if not tx["ok"] or not value:
            return ""
        if tx["data"] == CAPITAL_TAG:
            pocket, kind = "@capital", "capital_funding"
        else:
            customer = db.one("SELECT name FROM identities WHERE tag=? AND role='customer'", tx["data"])
            if customer:
                owner = customer["name"]
                pocket, kind = available(owner), "deposit"
            else:
                pocket, kind = "@suspense", "unassigned_deposit"
        db.move(asset, "@custody", pocket, value, h)
    db.sql("INSERT INTO settlements VALUES (?,?,?,?,?,?)", (asset, h, height, kind, owner, str(value)))
    return reason


def stall(store, asset, cause=None):
    with store.transaction() as db:
        row = db.one("SELECT * FROM chains WHERE asset=?", asset)
        if row and not row["halted"]:
            db.sql("UPDATE chains SET last_sync=0,halted=? WHERE asset=?", (cause or "", asset))
            if cause:
                db.event("worker", "chain_halted", {"asset": asset, "reason": cause})


def sync_one(store, net, gateway, batch=30):
    now = int(time.time())
    try:
        gateway.identity(net)
        target = tip(gateway, net, now)
        witness = replace(net, rpc=net.witness_rpc, witness_rpc="") if net.witness_rpc else None
        if witness:
            gateway.identity(witness)
            target = min(target, tip(gateway, witness, now))
        with store.transaction(False) as db:
            cursor = db.one("SELECT * FROM chains WHERE asset=?", net.asset)
        if cursor and cursor["halted"]:
            raise Fault("Settlement halted: " + cursor["halted"], 503)
        if cursor is None:
            require(target >= net.anchor, "Opening checkpoint is not final yet", 503)
            anchor = gateway.block(net, net.anchor)
            if anchor["hash"].lower() != net.anchor_hash:
                raise Conflict("Opening checkpoint hash mismatch")
            opening = gateway.balance(net, net.anchor)
            if witness and (gateway.block(witness, net.anchor)["hash"].lower() != net.anchor_hash or
                            gateway.balance(witness, net.anchor) != opening or gateway.code(witness, net.vault, net.anchor) != "0x"):
                raise Conflict("Settlement nodes disagree on the opening checkpoint")
            if gateway.code(net, net.vault, net.anchor) != "0x":
                raise Conflict("Custody account must be an ordinary address")
            if gateway.block(net, net.anchor)["hash"].lower() != net.anchor_hash:
                raise Conflict("Opening checkpoint changed")
            with store.transaction() as db:
                if not db.one("SELECT asset FROM chains WHERE asset=?", net.asset):
                    db.sql("INSERT INTO chains VALUES (?,?,?,0,'')", (net.asset, net.anchor, net.anchor_hash))
                    if opening:
                        db.move(net.asset, "@custody", "@capital", opening, "opening:" + net.anchor_hash)
                    db.event("worker", "opening_checkpoint", {"asset": net.asset, "height": net.anchor, "balance_atoms": str(opening)})
                cursor = db.one("SELECT * FROM chains WHERE asset=?", net.asset)
        if target < cursor["height"]:
            raise RpcError("RPC is behind the committed checkpoint")
        if gateway.block(net, cursor["height"])["hash"].lower() != cursor["hash"]:
            raise Conflict("Previously settled block changed. Independent review required")
        if witness and gateway.block(witness, cursor["height"])["hash"].lower() != cursor["hash"]:
            raise Conflict("Witness disagrees on previously settled block")
        for height in range(cursor["height"] + 1, min(cursor["height"] + batch, target) + 1):
            block, transactions, observed = collect(gateway, net, height)
            if witness:
                peer, effects, reserve = collect(gateway, witness, height)
                if peer["hash"].lower() != block["hash"].lower() or effects != transactions or reserve != observed:
                    raise Conflict("Settlement nodes disagree on finalized custody activity")
            with store.transaction() as db:
                row = db.one("SELECT * FROM chains WHERE asset=?", net.asset)
                require(not row["halted"], "Chain halted", 503)
                if row["height"] != height - 1:
                    return  # Another watcher has advanced this cursor.
                if block["parentHash"].lower() != row["hash"]:
                    raise Conflict("Block does not extend settlement checkpoint")
                reasons = [msg for tx in transactions if (msg := settle(db, net, height, tx))]
                expected = -db.balance(net.asset, "@custody")
                if expected != observed:
                    reasons.append(f"Reserve mismatch at {height}: expected {expected}, node returned {observed}")
                if db.balance(net.asset, "@capital") < 0:
                    reasons.append("Operator capital is negative")
                halt = " | ".join(reasons)
                db.sql("UPDATE chains SET height=?,hash=?,halted=?,last_sync=0 WHERE asset=?",
                       (height, block["hash"].lower(), halt, net.asset))
                if halt:
                    db.event("worker", "chain_halted", {"asset": net.asset, "reason": halt})
            if halt:
                raise Fault("Settlement halted: " + halt, 503)
        with store.transaction() as db:
            row = db.one("SELECT * FROM chains WHERE asset=?", net.asset)
            if row["height"] == target and not row["halted"]:
                db.sql("UPDATE chains SET last_sync=? WHERE asset=?", (now, net.asset))
    except Conflict as err:
        stall(store, net.asset, str(err))
        raise
    except (RpcError, KeyError, TypeError, ValueError, Fault):
        stall(store, net.asset)
        raise
