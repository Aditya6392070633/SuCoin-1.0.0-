import hashlib
import json
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

from .config import ASSETS, IDENTIFIER, Fault, canonical, require

SCHEMA = Path(__file__).with_name("schema.sql")


class Session:
    def __init__(self, connection, pg):
        self.connection, self.pg = connection, pg

    def sql(self, query, args=()):
        sql = query.replace("?", "%s") if self.pg else query
        return self.connection.execute(sql, tuple(args))

    def one(self, query, *args):
        row = self.sql(query, args).fetchone()
        return dict(row) if row is not None else None

    def rows(self, query, *args):
        return [dict(row) for row in self.sql(query, args).fetchall()]

    def next_id(self):
        return int(self.one("UPDATE meta SET value=CAST(CAST(value AS BIGINT)+1 AS TEXT) WHERE key='sequence' RETURNING value")["value"])

    def event(self, actor, kind, detail):
        self.sql("INSERT INTO events VALUES (?,?,?,?,?)",
                 (self.next_id(), int(time.time()), actor, kind, canonical(detail)))

    def balance(self, asset, pocket):
        row = self.one("SELECT atoms FROM balances WHERE asset=? AND pocket=?", asset, pocket)
        return int(row["atoms"]) if row else 0

    def move(self, asset, debit, credit, atoms, reference):
        require(asset in ASSETS and type(atoms) is int and atoms > 0 and debit != credit,
                "Invalid journal entry")
        for pocket, change in ((debit, -atoms), (credit, atoms)):
            new = self.balance(asset, pocket) + change
            require(new >= 0 or pocket in ("@custody", "@capital"), "Insufficient available balance", 409)
            self.sql("INSERT INTO balances VALUES (?,?,?) ON CONFLICT(asset,pocket) DO UPDATE SET atoms=excluded.atoms",
                     (asset, pocket, str(new)))
        self.sql("INSERT INTO moves VALUES (?,?,?,?,?,?,?)",
                 (self.next_id(), int(time.time()), asset, debit, credit, str(atoms), reference))

    def operational(self, max_age):
        rows = self.rows("SELECT * FROM chains")
        now = int(time.time())
        require(len(rows) == len(ASSETS) and all(not r["halted"] and
                0 <= now - r["last_sync"] <= max_age for r in rows),
                "Settlement unavailable. Check both chain workers and reconciliation.", 503)


class Store:
    """All money mutations use a single serialized transaction on either backend."""
    def __init__(self, settings):
        self.cfg = settings
        self.pg = settings.database.startswith(("postgresql://", "postgres://"))
        require(settings.profile != "commissioned" or self.pg,
                "Set BREAKWATER_DATABASE_URL to the commissioned PostgreSQL database")

    def connect(self):
        if self.pg:
            import psycopg
            from psycopg.rows import dict_row
            return psycopg.connect(self.cfg.database, autocommit=True, row_factory=dict_row, connect_timeout=8)
        p = Path(self.cfg.database)
        p.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(p, isolation_level=None, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA synchronous=FULL")
        return db

    @contextmanager
    def transaction(self, write=True):
        con = self.connect()
        try:
            if self.pg:
                con.execute("BEGIN" if write else "BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY")
                if write:
                    con.execute("SELECT pg_advisory_xact_lock(13774052)")
            else:
                con.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield Session(con, self.pg)
            con.execute("COMMIT")
        except BaseException:
            if (not self.pg and con.in_transaction) or self.pg:
                con.execute("ROLLBACK")
            raise
        finally:
            con.close()

    def init(self):
        if not self.pg:
            con = self.connect()
            try:
                con.execute("PRAGMA journal_mode=WAL")
            finally:
                con.close()
        with self.transaction() as db:
            for stmt in SCHEMA.read_text().split(";"):
                if stmt.strip():
                    db.sql(stmt)
            db.sql("INSERT INTO meta VALUES ('sequence','0') ON CONFLICT DO NOTHING")
            identity = canonical([1, [self.cfg.networks[a].identity() for a in ASSETS]])
            db.sql("INSERT INTO meta VALUES ('identity',?) ON CONFLICT DO NOTHING", (identity,))
            require(db.one("SELECT value FROM meta WHERE key='identity'")["value"] == identity,
                    "Database is bound to different networks, custody addresses or schema settings")
            for name in ("moves", "events", "trades", "settlements", "approvals"):
                if self.pg:
                    db.sql("""CREATE OR REPLACE FUNCTION bw_append_only() RETURNS trigger LANGUAGE plpgsql
                              AS $$ BEGIN RAISE EXCEPTION 'append-only record'; END; $$""")
                    db.sql(f"DROP TRIGGER IF EXISTS bw_immutable ON {name}")
                    db.sql(f"CREATE TRIGGER bw_immutable BEFORE UPDATE OR DELETE ON {name} FOR EACH ROW EXECUTE FUNCTION bw_append_only()")
                else:
                    for op in ("DELETE", "UPDATE"):
                        db.sql(f"CREATE TRIGGER IF NOT EXISTS imm_{name}_{op} BEFORE {op} ON {name} BEGIN SELECT RAISE(ABORT,'append-only record'); END")

    def enroll(self, name, role):
        require(isinstance(name, str) and IDENTIFIER.fullmatch(name), "Invalid principal name")
        require(role in ("customer", "reviewer", "treasurer", "auditor"), "Invalid role")
        token = secrets.token_urlsafe(32)
        with self.transaction() as db:
            require(not db.one("SELECT name FROM identities WHERE name=?", name), "Principal already exists", 409)
            db.sql("INSERT INTO identities VALUES (?,?,?,?,1)", (name, role, digest(token), "0x" + secrets.token_hex(32)))
            db.event("operator", "enroll", {"name": name, "role": role})
        return token

    def rotate(self, name):
        token = secrets.token_urlsafe(32)
        with self.transaction() as db:
            require(db.one("SELECT name FROM identities WHERE name=? AND enabled=1", name), "No active principal", 404)
            db.sql("UPDATE identities SET token_hash=? WHERE name=?", (digest(token), name))
            db.event("operator", "rotate", {"name": name})
        return token


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def authenticate(db, token, roles=()):
    require(isinstance(token, str) and 32 <= len(token) <= 128, "Valid access token required", 401)
    row = db.one("SELECT name,role,tag FROM identities WHERE token_hash=? AND enabled=1", digest(token))
    require(row, "Invalid or revoked access token", 401)
    require(not roles or row["role"] in roles, "Role cannot perform this operation", 403)
    return row


def once(db, actor, key, operation, payload, fn):
    require(isinstance(key, str) and re.fullmatch(r"[A-Za-z0-9_-]{8,100}", key), "Supply a unique Idempotency-Key")
    fingerprint = digest(canonical([operation, payload]))
    prev = db.one("SELECT * FROM requests WHERE actor=? AND key=?", actor, key)
    if prev:
        require(prev["payload"] == fingerprint, "Idempotency key already used for different input", 409)
        return json.loads(prev["response"])
    result = fn()
    db.sql("INSERT INTO requests VALUES (?,?,?,?)", (actor, key, fingerprint, canonical(result)))
    return result
