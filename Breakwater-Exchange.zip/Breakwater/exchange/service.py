import time
from .config import ASSETS, COST_UNIT, LOT, display, exact, require
from .market import (approve, cancel_order, cancel_withdrawal, create_order, order_view, prepare,
                     request_withdrawal, trade_view, withdrawal_view, locked)
from .store import authenticate, once


def audit(db):
    replay = {}
    for row in db.rows("SELECT asset,debit,credit,atoms FROM moves ORDER BY id"):
        n = int(row["atoms"])
        require(n > 0 and row["debit"] != row["credit"], "Corrupt journal entry", 500)
        for key, sign in ((row["debit"], -1), (row["credit"], 1)):
            pair = (row["asset"], key)
            replay[pair] = replay.get(pair, 0) + n * sign
    actual = {(r["asset"], r["pocket"]): int(r["atoms"]) for r in db.rows("SELECT * FROM balances")}
    require(replay == actual, "Balance cache differs from journal replay", 500)
    expected = {}
    for order in db.rows("SELECT * FROM orders WHERE status='open'"):
        a = "base" if order["side"] == "sell" else "quote"
        scale = LOT if a == "base" else order["price"] * COST_UNIT
        expected[(a, locked(order["owner"], "order", order["id"]))] = order["remaining"] * scale
    for w in db.rows("SELECT * FROM withdrawals WHERE status IN ('requested','approved','prepared')"):
        expected[(w["asset"], locked(w["owner"], "withdrawal", w["id"]))] = int(w["atoms"])
    reserved = {k: v for k, v in actual.items() if v and (":withdrawal:" in k[1] or ":order:" in k[1])}
    require(expected == reserved, "Reservation totals differ from orders or withdrawals", 500)
    require(all(v >= 0 or k[1] in ("@capital", "@custody") for k, v in actual.items()), "Negative customer liability", 500)
    return {a: {"custody": display(-actual.get((a, "@custody"), 0)),
                "capital": display(actual.get((a, "@capital"), 0)),
                "unassigned": display(actual.get((a, "@suspense"), 0)),
                "customer_liabilities": display(sum(v for (asset, k), v in actual.items() if asset == a and not k.startswith("@")))}
            for a in ASSETS}


def snapshot(db, cfg, actor):
    chains = {r["asset"]: r for r in db.rows("SELECT * FROM chains")}
    now = int(time.time())
    result = {"user": actor["name"], "role": actor["role"], "networks": {}, "book": {}, "trades": []}
    for a in ASSETS:
        chain = chains.get(a)
        n = cfg.networks[a]
        ready = bool(chain and not chain["halted"] and 0 <= now - chain["last_sync"] <= cfg.max_age)
        result["networks"][a] = {"symbol": n.symbol, "chain_id": n.chain_id, "genesis": n.genesis, "vault": n.vault,
                                "height": chain["height"] if chain else None, "ready": ready,
                                "halted": bool(chain and chain["halted"])}
    for side, direction in (("buy", "DESC"), ("sell", "ASC")):
        result["book"][side] = [order_view(r) for r in db.rows(
            f"SELECT * FROM orders WHERE status='open' AND side=? ORDER BY price {direction},id LIMIT 40", side)]
    result["trades"] = [trade_view(r) for r in db.rows("SELECT * FROM trades ORDER BY id DESC LIMIT 50")]
    if actor["role"] == "customer":
        name = actor["name"]
        result["deposit_tag"] = actor["tag"]
        result["balances"] = {}
        for a in ASSETS:
            # Exact owner-name comparison; SQL wildcards in names must not cross customer boundaries.
            rows = db.rows("SELECT pocket,atoms FROM balances WHERE asset=? AND substr(pocket,1,?)=?", a, len(name) + 1, name + ":")
            free = db.balance(a, name + ":available")
            result["balances"][a] = {"available": display(free), "reserved": display(sum(int(r["atoms"]) for r in rows) - free)}
        result["orders"] = [order_view(r) for r in db.rows("SELECT * FROM orders WHERE owner=? ORDER BY id DESC LIMIT 80", name)]
        withdrawals = db.rows("SELECT * FROM withdrawals WHERE owner=? ORDER BY id DESC LIMIT 80", name)
        result["destinations"] = db.rows("SELECT asset,address,valid_from FROM destinations WHERE owner=? ORDER BY valid_from", name)
        result["deposits"] = [{**r, "amount": display(r["atoms"])} for r in db.rows(
            "SELECT asset,height,hash,atoms FROM settlements WHERE owner=? AND kind='deposit' ORDER BY height DESC LIMIT 50", name)]
    else:
        withdrawals = db.rows("SELECT * FROM withdrawals ORDER BY id DESC LIMIT 100")
        result["checkpoints"] = chains
        result["events"] = db.rows("SELECT * FROM events ORDER BY id DESC LIMIT 40")
    result["withdrawals"] = [withdrawal_view(db, r) for r in withdrawals]
    return result


class Service:
    def __init__(self, store, gateway):
        self.store, self.cfg, self.gateway = store, store.cfg, gateway

    def read(self, token):
        with self.store.transaction(False) as db:
            return snapshot(db, self.cfg, authenticate(db, token))

    def change(self, token, key, op, data):
        roles = {"order": "customer", "cancel-order": "customer", "withdraw": "customer", "cancel-withdrawal": "customer",
                 "approve": "reviewer", "prepare": "treasurer"}
        require(op in roles, "Unknown command", 404)
        # Reject unauthenticated traffic before it enters the global money-write queue.
        with self.store.transaction(False) as reader:
            authenticate(reader, token, [roles[op]])
        with self.store.transaction() as db:
            actor = authenticate(db, token, [roles[op]])["name"]
            def execute():
                if op == "order":
                    return create_order(db, self.cfg, actor, data)
                if op == "withdraw":
                    return request_withdrawal(db, self.cfg, actor, data)
                exact(data, ["id"])
                ident = data["id"]
                require(type(ident) is int and 0 < ident < 2**53, "Invalid ID")
                if op == "cancel-order":
                    return cancel_order(db, actor, ident)
                if op == "cancel-withdrawal":
                    return cancel_withdrawal(db, actor, ident)
                if op == "approve":
                    return approve(db, self.cfg, actor, ident)
                return prepare(db, self.cfg, actor, ident, self.gateway)
            return once(db, actor, key, op, data, execute)
