"""Cross-platform launcher. In PowerShell use py -3 run.py test, then py -3 run.py start."""
import argparse
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PY=ROOT/".venv"/("Scripts/python.exe" if os.name=="nt" else "bin/python")
LAB=ROOT/"runtime"/"lab"


def lab_env():
    # Workstation acceptance must never inherit live RPCs, keys or a live database override.
    e=os.environ.copy()
    for key in ("BREAKWATER_DATABASE_URL","BREAKWATER_BASE_RPC","BREAKWATER_QUOTE_RPC","BREAKWATER_BASE_WITNESS_RPC","BREAKWATER_QUOTE_WITNESS_RPC","BREAKWATER_CONFIG","BREAKWATER_TEST_PG"):
        e.pop(key,None)
    return e


def run(args):
    subprocess.run([str(p) for p in args],cwd=ROOT,env=lab_env(),check=True)


def prerequisites():
    if not shutil.which("docker"):
        raise SystemExit("Install/start Docker Desktop with the WSL 2 Linux engine (Windows) or Docker Engine and Compose (Linux), then retry.")
    run(["docker","compose","version"])
    result=subprocess.run(["docker","info","--format","{{.OSType}}"],capture_output=True,text=True)
    if result.returncode!=0 or result.stdout.strip()!="linux":
        raise SystemExit("Start the Linux Docker engine, then retry. The node image is a Linux image.")
    if not PY.exists():
        run([sys.executable,"-m","venv",str(ROOT/".venv")])
    installed=subprocess.run([str(PY),"-c","from importlib.metadata import version; assert version('eth-account') == '0.13.7'"],capture_output=True)
    if installed.returncode:
        run([PY,"-m","pip","install","-r","network/requirements.txt"])


def serve():
    env=lab_env()
    worker=subprocess.Popen([str(PY),"-m","exchange","worker"],cwd=ROOT,env=env)
    server=subprocess.Popen([str(PY),"-m","exchange","serve"],cwd=ROOT,env=env)
    try:
        print("Open http://127.0.0.1:8080 · Ctrl+C stops the console and watcher.",flush=True)
        while server.poll() is None and worker.poll() is None:
            time.sleep(0.4)
        if server.poll() not in (None,0) or worker.poll() not in (None,0):
            raise SystemExit("A service exited. Inspect its error above.")
    except KeyboardInterrupt:
        pass
    finally:
        for child in (server,worker):
            if child.poll() is None:child.terminate()
        for child in (server,worker):child.wait()


def main():
    if sys.version_info < (3,11):
        raise SystemExit("Python 3.11 or newer is required.")
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("action",choices=("test","start","acceptance","stop","logs"))
    command=p.parse_args().action
    if command=="test":
        run([sys.executable,"-m","unittest","discover","-s","tests","-t",".","-v"]);return
    if command in ("stop","logs"):
        run(["docker","compose","-f",LAB/"compose.json",command]);return
    prerequisites()
    if not LAB.exists():run([PY,"-m","network.lab","create"])
    run([PY,"-m","network.lab","up"])
    run([PY,"-m","exchange","init"])
    if command=="acceptance" or not any(LAB.glob("passed-*.json")):
        run([PY,"-m","network.acceptance"])
    if command=="start":
        print("Find the generated seller or buyer access token in runtime/lab/access-*.json.",flush=True)
        serve()


if __name__=="__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        raise SystemExit(e.returncode)
